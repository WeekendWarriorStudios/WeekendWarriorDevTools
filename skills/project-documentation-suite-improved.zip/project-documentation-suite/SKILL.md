---
name: project-documentation-suite
description: >-
  Establish, author, improve, and audit project documentation suites and individual
  document contracts for Weekend Warrior Studios. Use for documentation inventories,
  project-specific documentation requirements, GDDs, system specifications, technical
  designs, production handoffs, traceability, milestone readiness, and documentation
  change control. Supports game titles and conditional profiles for applications,
  engines, reusable plugins, asset libraries, and R&D. Distinguishes approved project
  intent, shared capability contracts, implementation evidence, and proposed changes.
---

# Project Documentation Suite

## 1. Purpose and operating boundary

Create a coherent, maintainable documentation system that answers:
1. Why does this project exist, and what decisions must it preserve?
2. Which documents and sections are required for its actual scope and lifecycle stage?
3. Who owns each decision, contract, deliverable, and approval?
4. What must each document contain to support implementation and verification?
5. What evidence supports readiness, and what remains unresolved?

Preserve the original three-tier structure. Treat tiers as information layers, not sequential lifecycle stages. All three evolve throughout development.

This skill produces documentation requirements, drafts, gap reports, and readiness recommendations. It does not approve releases, certify standards compliance, invent organizational authority, or establish new product policy without explicit approval. All new requirements introduced by this skill are proposed WWS defaults until adopted by the appropriate owner.

### Trigger conditions

Use when asked to create or improve a project documentation suite, define required documents, audit documentation, prepare a milestone handoff, reconcile conflicting specifications, or update documentation after an approved change.

Do not substitute this skill for source-code implementation, employee assessment, legal advice, platform certification, or execution of product tests. Coordinate with relevant available skills for those tasks without assuming they exist or have run.

### Modes

- **Plan:** Produce a tailored documentation inventory and document contracts.
- **Author:** Draft a requested document or suite against those contracts.
- **Audit:** Compare supplied documentation with applicable requirements and evidence.
- **Improve:** Preserve valid content and decisions, correct weaknesses, and provide a change summary.
- **Change impact:** Identify downstream documents, tests, consumers, and approvals affected by a change.
- **Gate review:** Assess documentation readiness for a specified milestone.

## 2. Source handling and decision integrity

Read supplied files before editing. Preserve their identifiers, valid frontmatter, approved decisions, terminology, and scope unless the user requests a change. Never treat extracted formatting as more authoritative than the source file.

Use connected project sources when available and necessary. If unavailable, state the scope limitation and work from supplied material. Never claim a repository, backlog, charter, test result, or restricted platform portal was inspected when it was not.

Resolve authority by subject, not by document age alone:
- Current approved studio governance controls ownership and shared boundaries.
- Approved project vision controls title identity, scope, and product policy.
- Released shared contracts control supported integration surfaces.
- Version-matched technical documentation controls claims about tool behavior.
- Implementation and test artifacts establish observed behavior, not automatic approval of design drift.
- Drafts, proposals, and assumptions remain explicitly labeled.

When authorities conflict, record both sources, affected requirements, impact, and the decision owner. Do not silently choose one or rewrite approved intent to match code.

For every material statement use one status: **Confirmed decision**, **Observed implementation**, **Proposed requirement**, **Assumption**, or **Unresolved**. Cite source location and revision where available. Never fabricate citations, approvals, owners, budgets, schedules, test results, or completion percentages.

## 3. Workflow

1. Identify mode, project, document scope, lifecycle stage, and supplied sources.
2. Extract approved vision, non-goals, constraints, architecture choices, and ownership.
3. Build the project profile and list missing information without blocking useful work.
4. Select applicable document contracts from Section 9.
5. Map existing artifacts to contracts; recognize equivalent sections in combined documents.
6. Assign applicability, required-by gate, owner role, approval role, and canonical location.
7. Draft or revise documents using the universal contract and document-specific requirements.
8. Build traceability and cross-department handoff records.
9. Check contradictions, unsupported claims, stale references, missing evidence, and scope drift.
10. Deliver the requested artifacts, prioritized gaps, assumptions, and change summary.

If information is missing, produce the best supported result. Use `Unassigned`, `Unknown`, or `Proposed` rather than inventing details. Ask only if a consequential ambiguity cannot be safely represented as an assumption.

## 4. Three-tier information architecture

| Tier | Purpose | Decision ownership |
| --- | --- | --- |
| 1: Vision and product governance | Intent, scope, pillars, audience, requirements, roadmap, risks, decisions | Project product/creative leadership; studio governance for shared policy |
| 2: Systems and technical architecture | Behavior, composition, contracts, data, networking, performance, integration | Project owners for title rules; domain owners for reusable capabilities |
| 3: Execution, interface, and operations | UX, narrative, content, production handoffs, verification, build, release, support | Relevant craft/operations roles with project acceptance authority |

Do not assign all Tier 2 documents to Mechanics Lab. Framework architecture, AI reasoning, animation contracts, and project rules have different owners. Do not assume a division or studio exists merely because a template names it. Preserve Canvas Division, UX Studio, Narrative/Writing, Illustration, Publishing, and QA labels where confirmed; otherwise map the responsibility to an unassigned role pending charter confirmation.

Projects own title identity, concrete rules, balance, narrative, integration, and release decisions. Shared owners retain their reusable contracts. A project may consume and extend released capabilities through documented interfaces; title-specific content must not become a dependency of a shared foundation. Any exception requires an explicit decision, bounded scope, owner, risk, and exit plan.

## 5. Project profile and applicability

Record:
- Project ID, name, product type, purpose, lifecycle stage, and next gate.
- Confirmed ownership, consuming departments, and decision authority.
- Target platforms, engine/runtime and version, deployment topology, and supported inputs.
- Single-player/multiplayer scope, persistence, services, accounts, and data sensitivity.
- Narrative/content scope, localization, accessibility, modding, and external integrations.
- Shared capabilities, third-party dependencies, and compatibility constraints.
- Approved commercial boundaries, support model, and release cadence.
- Critical risks, known unknowns, and authoritative sources.

Use these applicability values:
- **Required:** Applies and must meet its contract by the assigned gate.
- **Conditional:** Required if its stated trigger is true; evaluate the trigger.
- **Recommended:** Useful but not a gate blocker unless adopted.
- **Not applicable:** Trigger demonstrably false, with rationale and reviewer.
- **Deferred:** Applies but is due at a later gate, with owner and due gate.
- **Unknown:** Insufficient evidence; never count as satisfied or not applicable.

A small team may combine documents. A section can satisfy a contract if its canonical location, ownership, traceability, and acceptance criteria are clear. Do not demand separate files merely to increase document count.

### Profile selection

| Profile | Required additions to common governance |
| --- | --- |
| Game | GDD, system specs, UX, technical design, relevant content contracts, playtest and release evidence |
| Multiplayer game | Networking, online lifecycle, authority, persistence, security, degraded-network tests; host migration only if supported |
| Narrative/episodic game | Canon, issue/act/chapter structure, branching/state persistence, content delivery and continuity |
| Application/tool | Product workflows instead of GDD, data integrity, file/API interoperability, recovery, user documentation |
| Engine/platform | Architecture, renderer/backend boundaries, SDK/API, tooling, compatibility, benchmarks, migration and reference integration |
| Reusable plugin | Neutral charter, public contract, dependency graph, integration guide, independent fixture, compatibility and migration |
| Asset library | Provenance, naming, source/export pipeline, asset contract, compatibility, validation and consumer examples |
| R&D/prototype | Hypothesis, experiment plan, constraints, evidence, limitations, decision and promotion/retirement criteria |

Apply overlays for XR, historical research, procedural worlds, destruction, user-generated content, or live services only when supported by project scope. For known titles, derive emphasis from supplied project sources rather than assuming every remembered feature is current.

## 6. Universal document contract

Every governed document must contain or link to:

### Metadata

Document ID; title/type; project or shared scope; tier; canonical location; owner role; custodian; reviewer and approval roles; revision; status; created/updated dates; applicable product/build/engine versions; parent/upstream sources; downstream consumers; confidentiality; review trigger; change history.

Allowed status: `Draft`, `In review`, `Approved`, `Superseded`, `Archived`. Approval requires an actual approval record. An AI-authored document remains Draft unless an authorized approval is supplied.

### Content

Purpose and audience; scope and non-goals; source/decision basis; definitions; requirements or specification; interfaces and handoffs; acceptance/verification; dependencies and constraints; risks/assumptions; unresolved decisions; maintenance triggers.

### Requirement record

Use stable IDs such as `<PROJECT>-REQ-<DOMAIN>-001`:
- Atomic, unambiguous requirement statement.
- Requirement type: functional, quality, interface, content, process, or release.
- Rationale and source; authority status; priority; owner.
- Applicability and required-by gate.
- Preconditions, inputs, outputs, failure behavior, and relevant limits.
- Acceptance criterion, verification method, test/evidence link.
- Dependencies, change impact, and approval state.

Use MUST for adopted mandatory requirements, SHOULD for recommendations, and MAY for permitted options. Proposed MUST statements must be clearly marked as proposals. Avoid words such as seamless, optimized, robust, or cinematic without observable criteria.

### Acceptance record

Define setup, action, expected result, measurement, threshold, environment, verifier, and evidence. Separate **documentation acceptance** from **product acceptance**. A complete specification is not proof that the feature works.

Example, explicitly proposed: `Given the approved extraction rules and a test session, when extraction succeeds, the authoritative inventory transaction commits once; duplicate requests do not duplicate rewards. Verify with the named integration test and build-specific evidence.` Numeric thresholds remain project decisions, not universal defaults.

## 7. Suite-level requirements

A suite is ready for its current gate only when:
- The inventory covers all applicable contracts and identifies canonical artifacts.
- Each required artifact has an owner, current revision, status, and required-by gate.
- Scope and non-goals agree with the approved project vision.
- Shared capability contracts are linked and version-pinned, not copied as competing authorities.
- Project-specific composition, tuning, adapters, and policy are explicit.
- Every current-gate requirement maps to design and planned verification; executed evidence is present when the gate requires it.
- Dependencies, handoffs, decisions, risks, and waivers are discoverable.
- Contradictions and unknown applicability are resolved or recorded as blockers.
- Release records identify the exact product build and documentation baseline.
- Access, confidentiality, retention, and archival rules are defined by the owner, not invented.

Maintain the chain: `Vision/pillar -> requirement -> design/contract -> work item -> implementation/content -> test -> evidence -> release decision`. A missing link is a gap, not permission to invent one.

## 8. Technical and compliance guardrails

- Do not mandate Unreal, GAS, Gameplay Tags, specific classes, or plugins for every project. Record the approved stack and version first.
- Use tags for extensible cross-system vocabulary where adopted. Do not ban enums universally; representation choices require a documented rationale.
- Specify server authority and trust boundaries for relevant multiplayer behavior. Prediction, reconciliation, rewind/rollback, and host migration are separate design choices, not automatic requirements.
- Document RPC direction, ownership, reliability, validation, rejection behavior, rate limits, and abuse cases. Epic documents WithValidation as a selectable server-RPC mechanism; failed validation disconnects the client. Do not use it as a blanket requirement or confuse invalid input with normal gameplay denial. See source S1.
- Record latency as RTT or one-way delay explicitly; define jitter, loss direction, topology, hardware, load, and acceptance thresholds. The original 150 ms / 2% loss values may be proposed scenarios, never silently adopted targets.
- Do not prescribe a 48-hour hotfix SLA without an approved support policy and operational capability.
- Accessibility requirements must identify product surface, target criteria, version, verification, and applicability. WCAG 2.2 concerns web content; it is not an automatic blanket native-game certification requirement. Map relevant guidance and separately verify platform/legal obligations. See S2.
- Test documentation guidance is not a mandate for headless GAS tests, particular automation tools, or a universal network profile. ISO/IEC/IEEE 29119-3:2021 addresses test documentation across lifecycle models. See S3.
- Do not reproduce restricted platform requirements, copyrighted standard clauses, or proprietary templates. Reference authorized sources and create original project requirements.
- Never claim ISO certification, legal compliance, accessibility conformance, or platform approval based solely on a generated checklist. Flag specialist review needs and unavailable authoritative evidence.

## 9. Document-specific contracts

All contracts inherit Section 6. Owner names below are role mappings, not assertions of staffing. For each applicable contract, record a project-specific approval role. Required-by gates are defaults subject to approved tailoring.

### Tier 1

#### D01: Project vision and product brief
- **Applies:** Every project; before concept approval.
- **Owner:** Project product/creative lead.
- **Contents:** Problem/opportunity, audience, value proposition, product identity, approved pillars and decision filters, experience goals, differentiators, scope/non-goals, constraints, success measures, commercial boundaries, major risks.
- **Acceptance:** Each pillar has observable implications; scope and exclusions are explicit; unverified market claims are labeled; decisions have sources.
- **Update:** Approved vision, audience, platform, scope, or commercial change.

#### D02: GDD or product workflow specification
- **Applies:** Games use GDD; tools/applications use workflow specification; before prototype acceptance, refined for production.
- **Owner:** Project design/product lead.
- **Contents:** Core loops/workflows, user actions, modes/tasks, progression, rewards/economy where applicable, failure/recovery, content structure, UX touchpoints, feature map, shared capability matrix, links to detailed specs.
- **Acceptance:** Core experience can be understood without implementation assumptions; each committed feature maps to a requirement; no duplicate authority for technical contracts.
- **Update:** Loop, workflow, rules, feature scope, progression, or balance policy changes.

#### D03: Requirements and traceability register
- **Applies:** Every project; initiated at concept, maintained through release.
- **Owner:** Project requirements custodian; product/technical owners approve their requirements.
- **Contents:** Section 6 requirement records, priorities, dependencies, lifecycle allocation, design/work/test/evidence links, coverage gaps, change history.
- **Acceptance:** Stable unique IDs; current-gate requirements have verification plans; unknowns and orphaned links are visible.
- **Update:** Any approved requirement, implementation baseline, or evidence change.

#### D04: Production roadmap and milestone plan
- **Applies:** Every project; before prototype work is committed.
- **Owner:** Project production lead.
- **Contents:** Deliverables, sequencing, dependencies, capacity assumptions, milestones, entry/exit criteria, documentation due gates, risk allowances, external commitments and decision points.
- **Acceptance:** Dates and effort are sourced or labeled estimates; each gate has observable exit evidence and decision authority.
- **Update:** Approved scope, dependencies, capacity, or milestone changes.

#### D05: Risk, assumption, decision, and exception register
- **Applies:** Every project; from concept onward.
- **Owner:** Project lead with domain decision owners.
- **Contents:** Risk IDs, likelihood/impact method, mitigations, triggers, owners; assumptions and validation plans; decisions and alternatives; exceptions, compensating controls, expiration and exit plan.
- **Acceptance:** High-impact risks have actions; accepted risk has real approval; unresolved decisions are not presented as facts.
- **Update:** New evidence, risk realization, expired exception, or changed constraint.

### Tier 2

#### D06: Gameplay mechanics and systems specification (MSS)
- **Applies:** Each committed gameplay system; before implementation commitment.
- **Owner:** Project systems designer for title policy; Mechanics Lab owner for reusable mechanic contract.
- **Contents:** Intent/scope, actors and actions, preconditions, state transitions, timing, cancellation/interruption, success/failure, tuning units/ranges/defaults, inputs, outputs, animation/audio/UX events, AI interactions, persistence and networking where relevant; GAS/tag/data mapping only if adopted.
- **Acceptance:** Normal, boundary, interrupted, invalid, and failure paths are specified; authority and policy are distinct; each behavior has testable criteria.
- **Update:** Behavior, state, tuning schema, input, authority, or integration changes.

#### D07: Technical design and architecture
- **Applies:** Engineered products; before production architecture approval.
- **Owner:** Project technical lead; shared framework owner for shared architecture.
- **Contents:** Context, modules and dependency direction, lifecycle, data/control flow, interfaces, threading/concurrency, error handling, resource ownership, extension points, build/deploy topology, alternatives, technical risks and decision links.
- **Acceptance:** Boundaries and dependencies are explicit; approved stack/version is identified; diagrams have textual explanations; design choices are not misrepresented as implemented.
- **Update:** Module boundaries, dependencies, lifecycle, deployment, or architecture decisions.

#### D08: Shared capability and integration contract
- **Applies:** Any shared plugin, service, framework, or library consumed or released.
- **Owner:** Shared domain owner for public contract; project integrator for adoption record.
- **Contents:** Neutral charter/non-goals, version and compatibility, public API/asset surface, dependency graph, initialization/shutdown, configuration, extension guide, project adapters, example/fixture, limitations, deprecation and migration.
- **Acceptance:** No shared-to-title dependency; consumer can integrate from documentation; project adoption pins a release; independent validation evidence is identified.
- **Update:** Shared release, API/schema break, compatibility, or consumer integration change.

#### D09: Data, persistence, and interoperability specification
- **Applies:** Structured runtime data, saved state, databases, import/export, or external APIs.
- **Owner:** Data/system technical owner.
- **Contents:** Schemas, IDs, units, ownership, validation, defaults, serialization, transactions, migration, recovery, corruption handling, conflict resolution, import/export formats and round-trip expectations; privacy links where relevant.
- **Acceptance:** Data lifecycle and invalid inputs are covered; migration and recovery are verifiable; sensitive fields are identified without exposing secrets.
- **Update:** Schema, format, storage, migration, or data ownership changes.

#### D10: Networking and online services specification
- **Applies:** Multiplayer, accounts, matchmaking, cloud persistence, or online services.
- **Owner:** Network/services technical owner with project rules owner.
- **Contents:** Topology, authority, replicated state, RPC contracts, prediction/reconciliation choices, session lifecycle, joins/leaves/reconnect, service failures, idempotency, network budgets, security links and test profiles; host migration only if supported.
- **Acceptance:** Trust boundaries and disconnect/recovery paths are explicit; network metrics have units and environment; no assumed rollback or service guarantees.
- **Update:** Topology, service/provider, authority, protocol, player load, or session policy changes.

#### D11: Performance and quality budget specification
- **Applies:** Production products and performance-sensitive prototypes.
- **Owner:** Technical lead with relevant craft/system owners.
- **Contents:** Target hardware/platforms, workloads, frame/response-time metrics, CPU/GPU/memory/storage/network budgets, loading and streaming limits, profiling methods, benchmark scenes, quality tiers and degradation rules.
- **Acceptance:** Every adopted target has measurement conditions and owner; budgets distinguish proposed targets from measured results.
- **Update:** Target hardware, content density, architecture, workload, or measured regression.

#### D12: Security, privacy, and dependency assurance
- **Applies:** Networked products, sensitive data, untrusted content, third-party distribution, or dependency risks.
- **Owner:** Security/privacy/dependency roles; specialist approval as applicable.
- **Contents:** Data flows and classification, threat model, trust boundaries, access control, secret handling, retention/deletion, abuse prevention, dependency versions/provenance/licenses, update risks, incident links and review obligations.
- **Acceptance:** Claims are source-backed; unresolved licensing/legal issues are flagged; controls map to risks and verification; no secrets in documentation.
- **Update:** Data collection, provider, dependency/license, trust boundary, or vulnerability change.

### Tier 3

#### D13: UX architecture and wireframe specification (UXS)
- **Applies:** User-facing interfaces; before interface implementation.
- **Owner:** UX role with project acceptance authority.
- **Contents:** Information architecture, user journeys, screen flows, wireframes, HUD/contextual feedback, input/focus navigation, widget states, loading/empty/error/retry/offline states, settings, confirmation and recovery, integration events.
- **Acceptance:** Supported inputs can complete critical flows; failure and focus paths are defined; visual assets are not mistaken for behavior specifications.
- **Update:** Flow, input, navigation, screen, feedback, or state changes.

#### D14: Accessibility and localization plan
- **Applies:** User-facing products; extent tailored to supported surfaces and release regions.
- **Owner:** UX/accessibility/localization roles.
- **Contents:** Applicable guidance and obligations, remapping, contrast/non-color cues, text scaling, subtitles/captions, motion/flash options, assistive support where relevant, string IDs, locales, font/glyph coverage, layout expansion, terminology and localized testing.
- **Acceptance:** Criteria have surface, version, test and evidence; language support is confirmed or proposed; legal applicability is not inferred from a template.
- **Update:** Surface, input, locale, guideline, platform obligation, or content change.

#### D15: Worldbuilding, narrative, and script bible (NSB)
- **Applies:** Authored story/world/character content; before narrative production.
- **Owner:** Narrative role; project creative owner approves canon.
- **Contents:** Canon and chronology, world/factions/characters, motivations and relationships, issue/act/chapter structure where used, branching and state dependencies, mission dialogue, bark conditions, script IDs, VO/localization handoffs, transmedia continuity if planned.
- **Acceptance:** Canon conflicts are flagged; branches and conditions are traceable; approved and proposed lore are separated; script versions are controlled.
- **Update:** Canon, plot, branch/state, character, script, or continuity decisions.

#### D16: Visual identity and concept callout package (VDS)
- **Applies:** Visual content production.
- **Owner:** Visual/art role, mapped to confirmed Canvas/Illustration/Art structure.
- **Contents:** Style and shape language, palettes, lighting/material direction, references and provenance, silhouettes, scale, turnarounds where needed, material callouts, source layers, export requirements, technical constraints and approval samples.
- **Acceptance:** Handoff has sufficient scale/material/source detail for the intended asset; references have provenance; visual approval is recorded, not invented.
- **Update:** Art direction, asset brief, pipeline, or technical constraints.

#### D17: Asset production and animation contract
- **Applies:** Art/animation assets or reusable libraries.
- **Owner:** Relevant craft owner; project owns title-specific acceptance.
- **Contents:** Asset IDs/catalog, naming/folders, provenance, source files, topology/UV/LOD/collision/material budgets where relevant; skeleton/rig/retarget/socket, root-motion, animation coverage, notifies/curves/layers where relevant; import/export presets, compatibility and validation.
- **Acceptance:** Assets meet the adopted contract in the target runtime; motion intent and gameplay authority remain distinct; source/export versions are linked.
- **Update:** Rig, skeleton, source pipeline, asset schema, runtime integration, or budgets.

#### D18: Level, mission, and procedural world specification
- **Applies:** Authored or generated playable spaces/content.
- **Owner:** Level/world/mission design roles with technical generation owner.
- **Contents:** Layout, objectives, encounters, traversal/readability, progression dependencies, streaming, navigation, spawn rules, generation inputs/seeds, terrain/infrastructure constraints, fallback and validation rules where relevant.
- **Acceptance:** Completion and failure paths are testable; procedural outputs have validation and reproducibility expectations; mission rules do not leak into shared generation kernels.
- **Update:** Layout, mission logic, generation rules, streaming, or world dependencies.

#### D19: Audio and cinematic specification
- **Applies:** Audio, VO, music, or cinematic production.
- **Owner:** Audio/cinematic roles with project creative acceptance.
- **Contents:** Event/cue IDs, triggering/priority, mixing/spatialization, source/export formats, VO/script links, localization, cinematic beats/shots, camera/animation handoffs, skip/pause/replay and gameplay transition behavior where relevant.
- **Acceptance:** Cues and sequences map to runtime conditions; asset/version links exist; interruption and transition behavior is specified.
- **Update:** Cue logic, scripts, mix, sequence, or runtime handoff changes.

#### D20: Test strategy and verification plan (QVP)
- **Applies:** Every production project; scaled plan for prototypes.
- **Owner:** QA/test role with technical/design reviewers.
- **Contents:** Scope, risk priorities, levels/types, manual/automated approach, environments/data, case/procedure IDs, expected results, network profiles where relevant, regression, accessibility/performance/content checks, entry/exit criteria, defect severity and escalation policy, evidence retention.
- **Acceptance:** Requirements map to tests; tests have observable outcomes; unavailable automation is not claimed; defect severity is separate from scheduling priority.
- **Update:** Requirements, risks, platforms, architecture, test environments, or defect patterns.

#### D21: Test results and acceptance evidence
- **Applies:** Executed verification and milestone acceptance.
- **Owner:** Test/evidence custodian; project/domain authority accepts results.
- **Contents:** Build/commit, configuration, environment, test IDs, execution date, expected/actual results, logs/artifacts, failures and retests, coverage limitations, residual risks, approval or rejection record.
- **Acceptance:** Results are reproducible and build-specific; unexecuted tests are labeled; failed tests and missing evidence cannot be hidden by a completeness score.
- **Update:** New build, retest, changed acceptance baseline, or corrected evidence.

#### D22: Build, deployment, and recovery runbook
- **Applies:** Reproducible builds, distributed products, or hosted services.
- **Owner:** Build/release/operations roles.
- **Contents:** Prerequisites and pinned tools, source/artifact versions, build/package steps, configuration and secret references, smoke checks, promotion, backups, rollback, save/data migration constraints, failure recovery and escalation.
- **Acceptance:** Steps have expected outputs and safe failure handling; rollback feasibility is explicit; credentials are referenced securely, not embedded.
- **Update:** Toolchain, packaging, infrastructure, migration, or deployment changes.

#### D23: Platform compliance and storefront operations matrix (POM)
- **Applies:** External distribution on confirmed platforms/storefronts.
- **Owner:** Publishing/release roles; specialist reviewers as needed.
- **Contents:** Authorized platform requirements and revisions, coverage/evidence/waivers, ratings and privacy review status, localized metadata/assets, achievements/saves/account/suspend behaviors where applicable, submission plan, release dependencies and contingency.
- **Acceptance:** Platform claims use authorized evidence; missing portal access is explicit; store dimensions and policies are verified rather than guessed; approval status is factual.
- **Update:** Platform policy, distribution region, submission, store assets, or release plan changes.

#### D24: Release, support, and lifecycle record
- **Applies:** Internal shared releases or external product releases.
- **Owner:** Release/product lead; shared owner for shared packages.
- **Contents:** Release manifest, versions and documentation baseline, change notes, compatibility, known limitations, acceptance links, migration/deprecation, user/integration guidance, support ownership, incident process, live content schedule if adopted, retrospective and retirement/export plan where relevant.
- **Acceptance:** Artifact and documentation versions match; limitations and unresolved risks are disclosed; approval is recorded; support promises match approved policy.
- **Update:** Release, hotfix, incident, migration, support policy, deprecation, or retirement.

## 10. Lifecycle gates

| Gate | Minimum documentation evidence |
| --- | --- |
| Concept | Profile, D01, initial D03/D05, applicable inventory and scope/non-goals |
| Prototype | D02, bounded D06/D07, relevant UX/content briefs, experiment/test plan and actual findings |
| Production/vertical slice | Baseline architecture and contracts, committed feature specs, relevant D08-D19, D04, D20, slice evidence |
| Alpha | Current committed scope, integrated-system specs, content coverage, traceability, known gaps and D21 |
| Beta | Stabilized requirements, regression/platform/performance/accessibility evidence, deployment/support drafts, residual risk review |
| Release candidate | Required evidence and approvals, D22-D24, matching build/document baseline, migrations and known issues |
| Post-release | Versioned changes, incident/retest evidence, compatibility, content updates and maintained support guidance |
| Retirement | Deprecation notice, consumer/data transition, archival and closure decision |

Do not assume every project uses Alpha/Beta terminology. Map its approved lifecycle to these evidence expectations. Documentation readiness and product readiness must be reported separately.

## 11. Audit and change-control method

Evaluate each applicable requirement using `Satisfied`, `Partial`, `Missing`, `Contradictory`, `Stale`, `Unverified`, or `Not applicable`. Cite exact document section/revision for each finding. Absence from supplied material is not proof that the artifact does not exist elsewhere.

Finding record: ID; affected document/requirement; evidence location; observed issue; expected contract; impact; severity; recommended correction; owner role; due gate; closure evidence.

- **Blocker:** Prevents the current gate, such as missing release approval, contradictory authority, or unavailable required evidence.
- **Major:** Significant ambiguity or incomplete contract likely to cause integration/rework.
- **Minor:** Local clarity, navigation, metadata, or formatting weakness without current critical impact.
- **Advisory:** Optional improvement.

These severities classify artifacts and risks, never employee performance. A finding closes only when its correction and evidence are checked. Do not report a numerical score unless requested and the denominator, weighting, exclusions, and unknowns are explicit. Never let a score override a blocker.

For changes: capture request and rationale; identify affected sources/requirements/consumers/tests; propose revisions; obtain actual approval where needed; update canonical artifacts and traceability; baseline the approved revision; archive superseded versions without deleting historical evidence.

## 12. Required outputs and reusable templates

### Suite plan / inventory

| Contract ID | Artifact/location | Applicability and rationale | Owner role | Approval role | Required-by gate | Status/revision | Upstream/downstream | Evidence/gap |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| D01 | Unknown | Required: product intent | Unassigned | Unassigned | Concept | Missing from supplied scope | D02/D03 | Vision source needed |

### Document specification

Use this outline for every selected contract:
1. Metadata and authority status.
2. Purpose, audience, applicability, required-by gate.
3. Scope/non-goals and source basis.
4. Mandatory sections and per-section content requirements.
5. Requirement records and interface/handoff details.
6. Documentation acceptance and product verification requirements.
7. Ownership, review, approval, and evidence expectations.
8. Risks, assumptions, unresolved decisions.
9. Update triggers and change history.

### Handoff record

`Producer role | Consumer role | Deliverable ID/version | Inputs | Interface/schema | Constraints | Acceptance evidence | Failure/rejection path | Change notification`

### Gate review

Report: reviewed scope and sources; gate; documentation readiness; product-evidence readiness; satisfied requirements; blockers; major/minor gaps; unknowns; waivers with real approvals; corrective actions; decision authority. Use `Ready`, `Not ready`, or `Indeterminate`; never invent approval.

### Improvement delivery

Return the revised skill/document, a concise change summary, preserved decisions, corrected unsupported mandates, and remaining source limitations. Save edited files under a new name. If a package is delivered, validate archive integrity and all referenced files. Do not claim installation or deployment merely because a file was created.

## 13. Self-check before delivery

- [ ] Correct project, mode, scope, and lifecycle identified.
- [ ] Supplied files read; source frontmatter and valid decisions preserved.
- [ ] Project ownership separated from reusable capability ownership.
- [ ] Every selected contract has applicability, owner, contents, acceptance and update triggers.
- [ ] Unknowns, proposals, and observed implementation clearly distinguished.
- [ ] Requirements are atomic and verification is measurable.
- [ ] No invented approvals, evidence, schedules, APIs, or compliance claims.
- [ ] No universal GAS, enum ban, rollback, host-migration, network target, or hotfix SLA mandate.
- [ ] Cross-document conflicts and current-gate blockers are visible.
- [ ] Links, IDs, versions, file/package structure, and change summary checked.

## 14. Sources and maintenance

Internal basis: the supplied project-documentation-suite SKILL.md and the WWS Development Core material supplied in this conversation. Preserve current approved charters over inferred department mappings. This revision expands the original skill; it is not evidence of studio adoption.

Public verification references, checked 2026-10-12:
- **S1:** [Epic Games: Remote Procedure Calls](https://dev.epicgames.com/documentation/unreal-engine/remote-procedure-calls-in-unreal-engine?lang=en-US). Server validation is a selectable mechanism and failed validation disconnects the invoking client. The retrieved page is labeled UE 5.8; verify the actual project version before prescribing API details.
- **S2:** [W3C: WCAG 2.2 Recommendation](https://www.w3.org/TR/WCAG22/). Web-content accessibility guidance; map scope and adopted criteria explicitly.
- **S3:** [ISO: ISO/IEC/IEEE 29119-3:2021](https://www.iso.org/standard/79429.html). Test documentation guidance across software lifecycle models; no standards-conformance claim is made here.

Recheck external sources when applying this skill to a new version, platform, jurisdiction, or release. Maintain a source register with title, version, authority, checked date, applicable scope, and unresolved verification needs. Consult authorized full standards and platform documentation for formal assessments; do not infer their detailed requirements from public abstracts.
