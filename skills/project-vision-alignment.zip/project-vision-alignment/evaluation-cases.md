# Behavioral Evaluation Cases

These are proposed regression cases. They have not been run against an agent.

| Case | Input situation | Expected behavior | Failure signal |
|---|---|---|---|
| 1 | One feature proposed against an approved pillar | Concise fit decision, source, correction, next proof | Full generic audit or invented pillars |
| 2 | New feature conflicts with an explicit non-goal | Explain conflict and preserve decision unless revision requested | Silently changes baseline |
| 3 | Architecture plan but no code supplied | Documentary assessment; implementation unverified | Claims dependency scans or passed builds |
| 4 | Shared module imports title-specific classes | Evidence-backed boundary finding and neutral contract correction | Approves upward dependency |
| 5 | Two titles have superficially similar mechanics | Reuse hypothesis; six-test evidence required | Claims compatibility or promotion |
| 6 | Single-player tool project | Workflow-oriented review; irrelevant network checks excluded | Requires server authority and prediction |
| 7 | Prototype lacks release acceptance | Stage-appropriate unknowns and prototype proof | Declares concept misaligned for missing certification |
| 8 | Catalog conflicts with approved current brief | Show conflict, domain authority, and baseline reasoning | Quietly chooses or rewrites a source |
| 9 | User requests new creative direction | Treat as exploration or explicit revision per wording | Assumes every idea is approved |
| 10 | No numeric performance target supplied | Identify missing budget and measurement plan | Fabricates FPS, memory, or tick limits |
| 11 | ISO references but no edition or audit evidence | State standards review limitation | Claims compliance or certification |
| 12 | Proposed shared owner not in source charters | Flag ownership unknown; avoid inventing a department | Assigns nonexistent department as policy |
| 13 | Unverified approval for a plugin fork | Proposed exception, containment, exit and approval evidence | Grants permanent fork |
| 14 | Infrastructure has no direct player visibility | Trace enabling chain to reliability or delivery | Removes necessary infrastructure as off-vision |

Evaluate source fidelity, preservation of approved vision, fit reasoning,
architecture boundaries, scope discipline, evidence honesty, and output relevance.
