 Project Portfolio Overview  
Overview and pitch summaries for active game development titles.

# **Project Summaries**

## **Deathmark**

Deathmark is an underground assassination extraction shooter where players hunt targets in a PvPvE arena to collect contracts, upgrade gear, and climb the ranks. Featuring a 3rd-person perspective, fast-paced action, and advanced parkour traversal locomotion, the game combines seamless gunplay with close-quarters melee combat. It offers a blend of tactical stealth action and high-stakes extraction gameplay set in a dark noir underworld.

## **Collateral Damage**

Collateral Damage is a realistic, true first-person shooter set in the pre-WWI world stage leading up to the Great War. It features realistic destruction, large-scale, mid-scale, and close-quarters battles reenacting historical conflicts from the late 19th and early 20th centuries, with highly realistic visual fidelity and immersive tactical game modes.

## **Colossus Rising**

Colossus Rising is a large-scale, online monster battle arena featuring team and squad-based gameplay objectives set in destructible cityscapes around the world. Modeled after classic monster brawlers, it offers monster customization, tiered elemental power mixing, and full-scale destruction across voxel-built terrain.

## **State of Ruin**

State of Ruin is a realistic extraction shooter set in a zombie apocalypse. Players squad up and venture out from their shelters to collect supplies from a body-cam perspective. Players collect supplies to keep their clan alive, and rescue or eliminate other skilled NPCs to add them to their clan, increasing requirements while aiding efficiency for other regions.

## **The Fifth Sun**

The Fifth Sun is a historical fiction recount where players play as a fictional, customizable character that lives alongside the Spanish conquest of Aztecs in 1517-1520. In a historical action stealth combat game, players decide to side with the historical conquerors, the rebellion states, or raise an army of their own to intervene in the entire event. The game is a third person stealth action combat.

## **Still Water**

Still Water is a high-octane survival and action shooter featuring fishing, hunting, farming, homesteading, and cabin building. The story follows a retired operative who moves to a remote woodland town with a stray dog companion, surviving off the land and defending against bandit raids, leading into a revenge-driven action narrative when a gang targets the area.

# **Portfolio Comparison Matrix**

| Project | Genre | Platform Focus | Primary Design Focus |
| :---- | :---- | :---- | :---- |
| **Deathmark** | PvPvE Extraction Shooter | PC / Console | Tactical stealth action, parkour traversal, and close-quarters gun-fu |
| **Collateral Damage** | First-Person Shooter | PC / Console | Realistic destruction, historical conflict battles, and immersive tactical modes |
| **Colossus Rising** | Monster Battle Arena | PC / Console | Monster customization, elemental power mixing, and voxel-built terrain destruction |
| **State of Ruin** | Extraction Shooter | PC / Console | Body-cam perspective, clan management, supply scavenging, and NPC recruitment |
| **The Fifth Sun** | Third-Person Stealth Action | PC / Console | Historical fiction setting, customizable protagonist, multiple factions, and third-person stealth action combat |
| **Still Water** | Survival / Action Shooter | VR Headsets | Homesteading, fishing/hunting survival, dog companion, and revenge-driven action |

