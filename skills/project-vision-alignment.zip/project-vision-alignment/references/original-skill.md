---
name: project-vision-alignment
description: Analyze a game project, feature specification, or architecture plan and align its vision, structure, and quality standards with Weekend Warrior Studios (WWS) company vision, hybrid studio-lab operating model, and ISO/IEC engineering quality gates. Use when reviewing game design documents (GDDs), technical specs, project pitches, or production roadmaps for compliance with WWS capability reuse, downward dependency rules, and quality standards.
---
# Project Vision Alignment

Analyze game proposals, feature designs, architectural specifications, and production plans to ensure strict alignment with the Weekend Warrior Studios (WWS) company vision, hybrid operating model, and portfolio quality benchmarks.

## When to Use

- Evaluating a game pitch, feature proposal, or game design document (GDD) for alignment with WWS company vision and operating standards.

- Reviewing technical architecture to enforce the separation between title identity and reusable foundation plugins.

- Auditing whether project mechanics, assets, or tools qualify for promotion to shared Labs or Studios versus remaining project-specific.

- Assessing project readiness against WWS quality gates, automated testing policies, and ISO/IEC 25010 / 29119 criteria.

- Reviewing cross-department handoffs between Projects Studio and foundational Labs or craft Studios.

## Alignment Evaluation Workflow

Execute this five-stage evaluation workflow when analyzing any project deliverable:

### 1. Architectural Boundary Audit (Hybrid Operating Model)

Verify adherence to the core WWS organizational and architectural principles:

- Mechanism over policy: Verify that shared systems provide reusable capability, while the project defines only game rules, balance values, feel, and identity.

- Downward dependency rule: Enforce that project modules depend on shared modules, but no shared module or plugin imports project headers, classes, or assets.

- Composition over copying: Ensure the project does not duplicate or fork shared Lab plugins (e.g., GameCore, AIFramework, GAS abilities). Projects must inject components, register handlers, or author data assets.

- Interface integrity: Verify all cross-boundary communications rely on Gameplay Tags, modular component injection, data assets (UPrimaryDataAsset), or typed messages rather than hard dependencies.

### 2. Departmental Responsibility Mapping

Map every project system and deliverable to its authoritative owner across WWS Labs and Studios:

- Frameworks Lab: Common vocabulary, lifecycle, persistence, save systems, replication contracts, and root Gameplay Tags.

- Mechanics Lab: Authoritative player actions (movement, combat, traversal, stealth, interactions) and net-predicted action execution.

- AI Lab: Project-agnostic agent reasoning, StateTrees, perception fusion, tactical queries, and coordination algorithms.

- Animation Studio: Character rigs, Control Rigs, motion libraries, Animation Blueprints, and motion matching.

- Art Studio and Canvas Division: 2D/3D visual production, UI vector design, material libraries, VFX systems, and environment kits.

- Quality and Testing Lab: Automation harnesses, headless CI testing, Gauntlet suites, and certification matrices.

- Hardware and Devices / Realms (XR) Division: Input abstraction, haptics, spatial tracking, and OpenXR pipelines.

- Data and Analytics Lab: Telemetry SDK integration, schema validation, A/B testing infrastructure, and remote configuration.

- Projects Studio: Game modes, narrative, worldbuilding, character identity, weapon rosters, difficulty curves, and balance.

### 3. Shared Portfolio Decision Test

When the project introduces new mechanics, tools, or assets, execute the 6-test filter to classify them as shared vs. project-specific:

1. Identity Test: Does the capability use domain-neutral terminology (e.g., XRGrabComponent, UWallRunComponent) rather than title, character, or faction lore?

2. Reuse Test: Does it support at least two distinct project use cases or satisfy an identified portfolio need?

3. Variability Test: Can variations across titles be handled via data assets, Gameplay Tags, or adapters without code forks?

4. Dependency Test: Can the system compile and pass tests in a blank Unreal Engine project without any project modules?

5. Contract Test: Does it possess a bounded public API surface and standalone automated tests?

6. Stewardship Test: Does a specific Lab or Studio formally accept long-term maintenance, documentation, and versioning ownership?

If any test fails, retain the feature strictly inside the project module. Do not prematurely generalize.

### 4. Quality Gate and ISO Verification

Audit the project against WWS Quality Requirements (ISO/IEC 25010 and ISO/IEC 29119 standards):

- Zero Contamination Check: Ensure no shared plugins contain references to the project's game name, character lore, or title-specific classes.

- Server Authority and Prediction: Ensure all gameplay mechanics and state changes are server-authoritative, with client-side prediction and RPC validation enabled.

- Performance and Resource Budgets: Check that tick budgets, memory limits, and Level-of-Detail (LOD) managers are specified for target hardware.

- Definition of Done (DoD) Compliance: Verify that every deliverable includes unit/functional tests, SDK-style documentation, and reference examples before promotion.

### 5. Alignment Gap Report Generation

Format the analysis output into a structured alignment report:

1. Executive Alignment Summary: High-level verdict (Aligned, Conditionally Aligned, or Non-Compliant) with core strategic rationale.

2. Boundary and Architecture Review: Line-by-line identification of policy leaks, upward dependencies, or unapproved plugin forks.

3. Departmental Ownership Matrix: Tabular mapping of project deliverables to responsible Labs and Studios.

4. Shared Asset Opportunities: Recommendations for capabilities to upstream into shared Lab portfolios.

5. Remediation Action Plan: Prioritized list of technical, architectural, and production changes needed to meet WWS standards.

## Gotchas

- Avoid premature generalization: Do not recommend promoting a mechanic to a Lab before it has proven stability within the project.

- Never permit project-level forks of shared foundations without an approved time-bound exception and an exit plan.

- Watch for hidden coupling where game designers hardcode enum states instead of using hierarchical Gameplay Tags.

- Ensure client prediction always has corresponding server-side validation to prevent network desynchronization.
