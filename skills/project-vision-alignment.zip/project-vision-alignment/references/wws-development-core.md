# **Hybrid Studio Lab Operating Model**

**Document Type:** Organizational Design Standard  
Operating Model: Studios produce games and content; Labs develop reusable technology and R\&D capabilities  
Applies To: Animation Studio, AI Lab, Art Studio, Mechanics Lab, Frameworks Lab, and Projects Studio

# **1\. Executive Decision**

Weekend Warrior Studios should operate as a hybrid product-line organization:

* Labs own reusable, project-agnostic technology, algorithms, mechanics, contracts, and engineering knowledge.  
* Animation Studio and Art Studio own specialized production capability, shared content libraries, craft standards, and project content execution.  
* Projects Studio owns each game’s product vision, narrative, rules, composition, concrete content requirements, integration, tuning, and release decisions.  
* No project owns or forks a shared foundation. Projects consume released capabilities through documented APIs, Gameplay Tags, interfaces, data assets, adapters, and content contracts.

This formalizes the separation already present in the internal architecture: shared foundations contain no title identity or gameplay policy, while projects supply concrete rules, content, data, and presentation. Epic’s modular-gameplay guidance likewise emphasizes standalone features and avoiding accidental dependencies, while Unreal modules provide explicit encapsulation and dependency boundaries.

The operating relationship deliberately keeps title identity below the shared-capability boundary while preserving an upward feedback path for requirements, defects, and proven lessons.

*Figure 1: Weekend Warrior Studios hybrid operating model: Labs create reusable, project-agnostic capabilities; content Studios create reusable production libraries; Projects Studio composes and customizes them into individual games, with governed feedback into the shared portfolio.*

# **2\. Organizational Principles**

1. **Mechanism over policy.** Shared groups provide capability; Projects Studio decides what that capability means in a particular game.  
2. **Composition over copying.** Projects configure, register, subclass, inject, or adapt shared assets; they do not clone them.  
3. **Dependencies point downward.** Project modules may depend on shared modules. Shared modules must never depend on a project.  
4. **Public contracts are intentional.** Anything consumed outside its owning department requires an identified API, schema, asset contract, or documented integration surface.  
5. **Creative ownership and craft ownership are distinct.** Projects Studio approves title direction; the relevant craft Studio owns how its discipline produces compliant work.  
6. **Quality is built at every gate.** Unreal provides unit, feature, functional, content-stress, and screenshot-comparison testing; WWS should apply the appropriate evidence before promotion or release.

# **3\. Department Charters**

## **Animation Studio**

**Mission:** Own the studio’s motion language, animation production capability, reusable animation assets, and animation-domain systems.

**Owns:**

* Shared skeletons, rigs, Control Rigs, retarget profiles, pose libraries, animation sequences, montages, blend spaces, motion databases, curves, notifies, and animation modifiers.  
* Reusable Animation Blueprints, Animation Layer Interfaces, linked-layer patterns, motion-warping setups, animation debugging assets, and animation pipeline tools.  
* Animation performance, visual continuity, root-motion policy, naming, import, validation, and documentation standards.  
* Project animation production: character, creature, traversal, combat, cinematic, and interaction animation.

**Does not own:**

* The gameplay authority that decides whether an action is legal.  
* Project combat rules, movement physics, damage, AI decisions, or narrative approval.  
* Generic engine lifecycle or cross-domain contracts better placed in Frameworks Lab.

**Primary deliverables:** Animation packages, reusable animation systems, rig specifications, integration contracts, project animation sets, validation reports, and motion-quality standards.

Boundary rule: Mechanics Lab emits motion intent and gameplay state; Animation Studio translates that intent into poses and animation behavior. Projects Studio selects title-specific style, coverage, and presentation. Linked Animation Layers demonstrate how shared functionality can remain separate while allowing per-item or per-project animation variation.

## **AI Lab**

Mission: Develop reusable intelligence, perception, reasoning, planning, coordination, and agent-development technology.

**Owns:**

* Reusable NPC intelligence plugins and algorithms.  
* Decision frameworks, StateTree/Behavior Tree tasks, utility scoring, EQS support, tactical queries, perception interpretation, navigation intelligence, group coordination, debugging, and AI-authoring tools.  
* Generic companion, squad, crowd, vehicle-agent, or faction-agent capabilities when they remain project-neutral.  
* AI test scenarios, determinism/authority contracts, performance instrumentation, and reusable simulation fixtures.

**Does not own:**

* Named characters, factions, personalities, dialogue, encounter scripts, mission-specific behavior, or difficulty curves.  
* Combat, traversal, inventory, or interaction implementations owned by other domains.  
* Project-authored behavior trees that encode a title’s encounter or narrative policy.

**Primary deliverables:** Versioned AI plugins, algorithm libraries, task/condition libraries, tactical-data contracts, authoring tools, sample agents, benchmarks, and integration documentation.

Boundary rule: AI Lab owns how an agent evaluates and selects actions. Mechanics Lab owns the reusable actions agents may request. Projects Studio owns which behaviors, priorities, personalities, and restrictions define a specific NPC. This matches the existing CompanionAI direction: a reusable kernel communicates through interfaces, adapters, registered executors, messages, Gameplay Tags, and soft references rather than embedding project behavior.

## **Art Studio**

Mission: Own visual-development practice, art production, shared visual libraries, and the technical readiness of visual assets.

**Owns:**

* Concept art, character art, environments, props, vehicles, weapons, materials, textures, VFX art, UI art, lighting art, branding assets, and marketing art.  
* Shared material functions, shaders, decals, trim sheets, texture libraries, kitbash libraries, VFX modules, art templates, and source-art standards.  
* Modeling, UV, topology, LOD, collision, material, texture, optimization, naming, import, and visual-review standards.  
* Project art production under the project’s approved art direction.

**Does not own:**

* Game rules, narrative canon, product scope, or title-level creative approval.  
* Rigging and motion assets owned by Animation Studio, although character topology and deformation readiness are jointly reviewed.  
* Generic runtime frameworks merely because they render art.

**Primary deliverables:** Visual-development packages, style-guide implementation, shared asset libraries, engine-ready project assets, performance-compliant content, and art validation reports.

Boundary rule: Projects Studio owns the creative brief and title art direction. Art Studio owns production methods, asset quality, source files, technical conformance, and reusable visual libraries. Shared libraries must remain stylistically adaptable; unmistakably title-specific characters, locations, iconography, and look-development stay with the project.

## **Mechanics Lab**

Mission: Research, prototype, productionize, and maintain reusable gameplay mechanics.

**Owns:**

* Combat, locomotion, traversal, stealth, interaction, vehicles, crafting, building, survival, inventory behavior, camera behavior, and similar player/world mechanics.  
* Mechanic state machines, GAS abilities/effects, reusable gameplay components, input-independent actions, mechanic data schemas, replication behavior, and designer-facing tuning surfaces.  
* Mechanic prototypes, test arenas, debug tooling, and reusable mechanic documentation.

**Does not own:**

* Foundational lifecycle, persistence, messaging, identity, networking abstraction, or common vocabulary owned by Frameworks Lab.  
* NPC reasoning owned by AI Lab.  
* Animation assets or visual production.  
* A project’s game modes, balance, win conditions, arsenal, mission rules, or final "feel" tuning.

**Primary deliverables:** Mechanic plugins, abilities, components, data assets, reference implementations, multiplayer tests, performance profiles, and mechanic-authoring guidance.

Boundary rule: Mechanics Lab owns what an actor can do and the authoritative rules of that action. Projects Studio owns when the mechanic is available, how it is balanced, and how it contributes to the game’s identity. Existing WWS material already distinguishes reusable combat and locomotion mechanics from project-supplied weapons, values, and animation content.

## **Frameworks Lab**

Mission: Steward the project-agnostic architecture and foundational systems used across the product portfolio.

**Owns:**

* GameCore and common vocabulary: stable IDs, shared structs, interfaces, root Gameplay Tags, logging, developer settings, authority context, and normalized results.  
* Framework and systems plugins: lifecycle, objective machinery, persistence, spawning, online abstraction, world state, rewards, camera foundations, validation, adapters, and integration infrastructure.  
* Dependency rules, public APIs, schemas, replication contracts, extension mechanisms, compatibility declarations, migrations, and architecture decision records.  
* Shared build, test, diagnostics, editor, and integration tooling that spans domains.

**Does not own:**

* Player-facing mechanic implementation best placed in Mechanics Lab.  
* AI reasoning or authored NPC behavior.  
* Animation or art production.  
* Project modes, narrative, balance, UI presentation, factions, maps, content catalogs, or title-specific subclasses.

**Primary deliverables:** Stable framework releases, SDK-style documentation, compatibility matrices, migration guides, architecture standards, conformance tests, and reference integrations.

Boundary rule: Frameworks Lab owns how systems interoperate, initialize, communicate, persist, replicate, and extend. It does not own the domain behavior layered on those contracts. Unreal’s module and plugin model supports this separation through standalone code units, private/public surfaces, explicit dependency graphs, and independently enabled functionality.

## **Projects Studio**

Mission: Turn shared technology and content capability into coherent, market-facing games.

**Owns:**

* Game concepts, product vision, genre, audience, scope, schedules, milestones, and release decisions.  
* Narrative, worldbuilding, storyboards, scripts, missions, levels, game modes, victory rules, factions, characters, progression policy, economies, balance, and difficulty.  
* Project modules, Game Feature composition, concrete data assets, leaf Gameplay Tags, content catalogs, project adapters, configuration, UI flows, maps, and title-specific presentation.  
* Integration, whole-game validation, certification readiness, and shipped-product maintenance.

**Does not own:**

* Shared plugin foundations or the right to silently fork them.  
* Shared APIs, root tags, studio-wide schemas, common rigs, or reusable libraries.  
* Defects reproducible inside a shared component’s documented contract.

**Primary deliverables:** Approved product briefs, storyboards, design documentation, project backlogs, configured experiences, integrated builds, acceptance evidence, and release candidates.

Boundary rule: Projects Studio composes and extends; it does not absorb shared ownership. Epic’s Lyra sample similarly separates a modular core and plugins from experience-specific maps, gameplay logic, and content loaded for a selected experience.

# **4\. Shared Versus Project-Specific Decision Test**

A proposed capability enters the shared portfolio only if it passes all six tests:

| Test | Shared when… | Project-specific when… |
| :---- | :---- | :---- |
| **Identity** | Uses neutral domain vocabulary | Contains title, faction, character, mission, or lore identity |
| **Reuse** | Has at least two credible use cases or one clear product-family need | Exists only to satisfy one scene, mode, or schedule |
| **Variability** | Differences can be expressed through data, policy, tags, interfaces, or adapters | Reuse requires branching on project names |
| **Dependency** | Builds and tests without a project module | Imports project classes, assets, or configuration |
| **Contract** | Has a bounded public surface and independent validation | Depends on undocumented project assumptions |
| **Stewardship** | A department accepts roadmap, documentation, compatibility, and support ownership | No long-term owner exists |

## **Classification Rules**

* A generic subsystem contract belongs to Frameworks Lab.  
* A reusable player/world action belongs to Mechanics Lab.  
* Reusable agent reasoning belongs to AI Lab.  
* Motion-domain assets and animation runtime arrangements belong to Animation Studio.  
* Shared visual-production assets belong to Art Studio.  
* Concrete game policy, narrative, composition, balance, and identity belong to Projects Studio.

When uncertain, start inside the project. Promote only after the abstraction is demonstrated; premature generalization is not reuse.

# **5\. Reusable Capability Lifecycle**

| Stage and gate | Accountable owner | Required collaborators | Exit evidence |
| :---- | :---- | :---- | :---- |
| **1\. Discovery / R\&D** | Originating department | Projects Studio plus affected domains | Problem statement, use cases, constraints, reuse hypothesis |
| **2\. Prototype** | Candidate domain owner | Representative project and downstream users | Playable/working proof; risks and rejected approaches recorded |
| **3\. Classification Gate** | Relevant Lab/Studio Lead | Frameworks Lab and project technical/design owner | Shared vs project decision; owner; dependency boundary |
| **4\. Production Design Review** | Shared owner | Frameworks, consuming disciplines, Projects | API/data contract, authority model, asset contract, test and migration plan |
| **5\. Production-Ready Release** | Shared owner | Frameworks Lab for cross-system changes | Versioned package, documentation, tests, example, known limitations |
| **6\. Project Integration** | Projects Studio | Shared owner and content Studios | Pinned version, integration adapter/configuration, acceptance plan |
| **7\. Project Extension** | Projects Studio | Contract owner consulted | Title code remains outside shared package; no upward dependency |
| **8\. Validation Gate** | Projects Studio for product; owner for component | All affected groups | Component tests plus integrated gameplay, content, network, performance, and visual validation |
| **9\. Maintenance / Versioning** | Owning department | Consuming projects | Defect triage, compatibility status, release notes, migration support |
| **10\. Deprecation / Lessons** | Owning department | All active consumers | Replacement path, adoption status, removal decision, reusable lessons backlog |

A shared release is not complete when the code merely works in its originating project. It is complete when it is independently packaged, contract-tested, documented, versioned, and adoptable without importing title identity. Unreal supports plugin-contained tests and standalone feature packaging, making this operationally enforceable.

# **6\. Required Collaboration Interfaces**

| Relationship | Required handoff |
| :---- | :---- |
| **Frameworks Lab ↔ Mechanics Lab** | Frameworks supplies lifecycle, authority, messaging, persistence, and extension contracts; Mechanics supplies domain actions without bypassing those contracts. |
| **Frameworks Lab ↔ AI Lab** | Frameworks supplies actor, replication, messaging, team, perception, and persistence contracts; AI supplies reasoning and agent services behind neutral interfaces. |
| **Mechanics Lab ↔ Animation Studio** | Mechanics publishes states, intents, timing windows, root-motion authority, and cancellation events; Animation supplies motion assets, graph/layer implementation, and animation feedback. |
| **Art Studio ↔ Animation Studio** | Art supplies deformation-ready meshes and visual requirements; Animation supplies skeleton, rig, socket, physics-asset, and motion-coverage specifications. |
| **Labs ↔ Projects Studio** | Projects submit use cases and constraints; Labs return versioned capabilities and integration guidance. Project urgency does not authorize title logic in shared code. |
| **Projects Studio ↔ Content Studios** | Projects approve briefs, style, narrative context, scope, and acceptance criteria; Art and Animation own craft execution and technical compliance. |

Cross-department communication must occur through owned contracts, not informal access to internal classes. Unreal explicitly distinguishes public and private module surfaces and recommends private dependencies wherever possible.

# **7\. Governance and Engineering Standards**

## **Architecture and Dependencies**

* Maintain a single ownership register for every plugin, module, shared asset library, schema, and root Gameplay Tag.  
* Shared code may depend only on Engine/third-party providers, Frameworks Lab, or explicitly approved lower-level shared contracts.  
* Cross-domain integrations use interfaces, Gameplay Tags, typed messages, delegates within ownership boundaries, data assets, or optional adapters.  
* Third-party types remain private behind studio-owned adapters when they would otherwise leak into gameplay.

## **Documentation Definition of Done**

Every shared release requires:

* Charter and explicit non-goals.  
* Public API or asset contract.  
* Dependency diagram.  
* Configuration and extension guide.  
* Example or test fixture with no title identity.  
* Authority/replication behavior where applicable.  
* Compatibility declaration.  
* Release notes, known limitations, migration notes, and deprecation status.

## **Releases and Compatibility**

Use Semantic Versioning for shared code and system packages: major for incompatible public-contract changes, minor for backward-compatible functionality, and patch for compatible fixes. Each project pins an approved version and records compatibility with its Unreal Engine version and dependent plugins.

A deprecated contract must remain available for at least one documented minor release with warnings and migration guidance; removal occurs through a major release. Released artifacts are immutable—corrections require a new version.

## **Testing and Validation**

* **Owning department:** Component correctness, contract tests, editor validation, reference content, and regression tests.  
* **Projects Studio:** Integrated gameplay, balance, content, maps, platform, performance, multiplayer, and release acceptance.  
* **Content Studios:** Visual/motion quality, source integrity, import settings, naming, budgets, and in-engine presentation.  
* **Joint defects:** Triaged against the failing contract boundary; the shared owner fixes contract defects, while the project fixes configuration or integration defects.

## **Shared Asset Standards**

Art and animation must use controlled naming, folders, source provenance, versioning, import presets, skeleton/material compatibility, validation rules, and explicit performance budgets. Epic recommends establishing common asset naming conventions early to reduce ambiguity and redundant variations.

# **8\. Leadership and Decision Model**

| Decision | Accountable role |
| :---- | :---- |
| **Shared domain roadmap and standards** | Relevant Lab or Studio Lead |
| **Framework architecture and dependency rules** | Frameworks Lab Lead |
| **Reusable mechanic design** | Mechanics Lab Lead |
| **Reusable AI architecture** | AI Lab Lead |
| **Animation systems and motion standards** | Animation Studio Lead |
| **Visual-production standards** | Art Studio Lead |
| **Product vision, narrative, scope, mode rules, and release** | Project Director / Product Lead |
| **Shared release approval** | Owning Lead; Frameworks Lab concurrence when public cross-system contracts change |
| **Project adoption approval** | Project technical and product leadership |
| **Breaking change** | Shared Architecture Review: owner, Frameworks Lab, and affected project representatives |
| **Ownership dispute** | Domain leads attempt resolution; unresolved cross-domain issues escalate to designated studio governance authority |

Review bodies approve boundaries and risks, not creative taste. Project leadership retains product authority; shared owners retain responsibility for the integrity of their public contracts.

# **9\. Compact Responsibility Matrix**

*Legend: A \= Accountable, R \= Responsible, C \= Consulted, I \= Informed*

| Category | Anim. | AI | Art | Mech. | Frameworks | Projects |
| :---- | :---- | :---- | :---- | :---- | :---- | :---- |
| **Core/framework plugins** | C | C | I | C | A/R | C |
| **Reusable gameplay mechanics** | C | C | C | A/R | C | C |
| **AI systems/algorithms** | C | A/R | I | C | C | C |
| **Animation systems/assets** | A/R | C | C | C | C | C |
| **Art libraries/tools/assets** | C | I | A/R | C | C | C |
| **Project code/content** | C | C | C | C | C | A/R |
| **Narrative/storyboards** | C | C | C | I | I | A/R |
| **Shared release integration** | C | C | C | C | C | A/R |
| **Component validation** | R | R | R | R | R | C |
| **Whole-game validation** | C | C | C | C | C | A/R |
| **Shared documentation** | R | R | R | R | R | C |
| **Project documentation** | C | C | C | C | C | A/R |

# **10\. Weekend Warrior Studios Rules of Thumb**

1. If it defines identity, story, rules, balance, a concrete catalog, or a title-specific experience, it belongs to Projects Studio.  
2. If it defines how systems initialize, communicate, persist, replicate, or extend, it belongs to Frameworks Lab.  
3. If it defines reusable player/world capability, it belongs to Mechanics Lab.  
4. If it defines reusable agent intelligence, it belongs to AI Lab.  
5. If it turns gameplay intent into motion, it belongs to Animation Studio.  
6. If it defines or produces the visual asset, it belongs to Art Studio.  
7. No shared package may import a project module or project identity.  
8. No project may fork a shared package without an approved, temporary exception and an exit plan.  
9. Prototype locally; generalize only after the variability and ownership are understood.  
10. A capability graduates into the shared portfolio only when it has an owner, neutral contract, tests, documentation, version, compatibility statement, and demonstrated consumer.

This model provides Weekend Warrior Studios with a clear product-line boundary: Labs and content Studios build durable organizational capability; Projects Studio turns that capability into distinct games.