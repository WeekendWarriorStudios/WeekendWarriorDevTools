# Review Rubric

These conventions are proposed additions to the skill, not adopted company policy.
WWS ownership and promotion requirements remain grounded in the source snapshots.

## Evidence states

- Confirmed decision: explicit approval or clear current instruction with locator.
- Documented proposal: described in a draft but not approved.
- Inference: reasoned interpretation; include premises and confidence.
- Recommendation: reviewer-proposed action, not a discovered requirement.
- Unknown: evidence missing or contradictory.
- Superseded: explicitly replaced; retain for change history, not current enforcement.

Implementation states are separate: specified, implemented, tested, accepted.
Never infer the later state from the earlier one.

## Verdicts

- Aligned: available evidence supports the reviewed decision with no material conflict.
- Conditionally aligned: compatible direction with named unresolved conditions.
- Misaligned: evidenced conflict with an approved promise, constraint, or boundary.
- Not assessable: missing or contradictory baseline prevents a defensible decision.

Give verdicts per dimension: strategic fit, experience coherence, architecture,
and milestone readiness. Do not collapse all dimensions into a false pass/fail.

## Finding severity and priority

Severity describes consequence; priority describes when action is needed.
- Critical: evidenced risk invalidates the reviewed gate or protected core promise.
- Major: material boundary, experience, or delivery issue requiring correction.
- Minor: localized ambiguity or weakness with a bounded correction.
- Opportunity: optional improvement, not a compliance failure.

Priority:
- P0: resolve before the specific blocked decision or gate.
- P1: resolve in the next relevant integration or validation step.
- P2: planned improvement or bounded research.
- P3: optional or deferred.

State the blocked decision, not an invented deadline. A missing release test can
block release without invalidating a concept pitch.

## Stage-appropriate evidence gates

These are review lenses, not replacements for the Development Core lifecycle.

| Review stage | Minimum useful evidence | Avoid demanding prematurely |
|---|---|---|
| Concept | Promise, pillars, non-goals, core-loop hypothesis, major risks | Release certification or completed production systems |
| Prototype | Representative experience proof, experiment results, feasibility risks | Full content coverage or mature shared API |
| Vertical slice | Integrated representative loop, style/motion proof, relevant target measurements | Complete launch content |
| Production | Owned contracts, scope traceability, integration plan, regression evidence | Assuming planned tests already passed |
| Shared promotion | All six tests, independent package validation, owner, documentation, version, compatibility | Promotion based on naming or theoretical reuse |
| Release review | Applicable acceptance, platform, network, performance, content and operational evidence | Approval or certification inferred from this report |

## Acceptance criteria pattern

For each important requirement specify:
- Context: platform, build, scenario, configuration, and constraints.
- Action/input: what the player, user, or system does.
- Observable result: behavior or output proving the requirement.
- Measurement: test, observation, benchmark, or review method.
- Threshold: sourced target or explicitly proposed target awaiting adoption.
- Evidence owner: accountable role and artifact location.
- State: specified, implemented, tested, or accepted.

For qualitative experience goals use representative scenarios and structured
observations. Do not disguise subjective judgment as a measured percentage.

## Exception record

Record exception ID, violated rule, reason, alternatives considered, affected
consumers, accountable role, required approval role, containment, exit condition,
expiry/review point if supplied, and evidence of approval. Unknown approval means
proposed exception, not permission. Never grant a silent permanent fork.

## Worked examples

### Feature compatible but outside the current proof
A draft adds a large crafting economy to a traversal-focused prototype.
If the baseline does not establish crafting as a core promise, classify it as
Optional or Research, not automatically Misaligned. Recommend Defer or Experiment
and identify the loop hypothesis it would test. Do not invent cost estimates.

### Shared code contains title policy
A shared action package imports a project's named faction class to determine damage.
With the dependency evidenced, identify the boundary violation. Preserve the damage
rule in project policy and expose a neutral extension contract. Mechanics owns the
reusable action; Projects owns faction rules; Frameworks is consulted on contracts.

### Portfolio reuse is plausible but unproven
The catalog describes traversal in Deathmark and large-scale destruction in
Colossus Rising. This does not establish compatible character scales, physics,
network assumptions, or budgets. Record a reuse hypothesis and required evidence;
do not claim the same traversal plugin already serves both.

### Missing multiplayer tests
A multiplayer plan describes prediction but supplies no results. Mark prediction
Specified and testing Unknown. Identify required authority and reconciliation proof
for applicable actions. Do not label every replicated state as requiring prediction.

### Tool review
A material-authoring tool adds an automated export workflow. Trace it to an evidenced
user workflow and output-integrity promise. Evaluate recoverability, interoperability,
and reproducibility where relevant, not combat loops or player progression.

### Conflict in platform direction
A catalog names one platform while a current approved brief names another. Report
both source scopes and the discrepancy. Prefer the approved brief for the current
project baseline if its authority is evidenced; do not silently rewrite the catalog.

### No project supplied
The user asks to strengthen this skill, not to review a particular game. Improve
the reusable review behavior. Do not choose a portfolio title and fabricate a vision
contract or alignment verdict for it.
