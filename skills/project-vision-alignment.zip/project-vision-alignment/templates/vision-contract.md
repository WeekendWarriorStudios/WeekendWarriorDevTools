# Project Vision Contract

Status: Proposed / Approved / Superseded
Project:
Product type:
Revision and source date:
Decision owner role:
Approval evidence: Unknown unless supplied

## Product promise
[Who does what, in what context, and why it matters.]

## Audience and experience
- Audience and use context:
- Player/user fantasy:
- Desired experience qualities:
- Core loop or primary workflow:
- Distinctive identity:

## Design pillars
| ID | Pillar | Observable meaning | Supporting systems | Anti-pattern | Validation | Source/status |
|---|---|---|---|---|---|---|

## Protected decisions and constraints
| ID | Decision or constraint | Why protected | Source | Status | Change authority |
|---|---|---|---|---|---|

## Non-goals
| ID | Excluded direction | Rationale | Source/status |
|---|---|---|---|

## Scope boundaries
- Current milestone proof:
- Launch scope, if established:
- Later expansion candidates:
- Separate reusable R&D:

## Success evidence and unknowns
| Promise/pillar | Representative scenario | Observable evidence | Target if supplied | Evidence state |
|---|---|---|---|---|

## Change log
| Change ID | Previous | Proposed | Change category | Impact | Decision/status |
|---|---|---|---|---|---|
