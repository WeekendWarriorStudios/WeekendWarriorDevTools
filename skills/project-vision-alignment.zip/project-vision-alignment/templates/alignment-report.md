# Project Vision Alignment Report

Project:
Artifact/revision:
Review mode and lifecycle stage:
Decision supported:
Evidence scope: Conceptual / Documentary / Implementation-backed

## 1. Executive decision
- Overall conclusion and rationale:
- Strategic fit:
- Experience coherence:
- Architecture conformance:
- Milestone readiness:
- Evidence confidence and limitation:
- Highest-value next action:

## 2. Source register
| Source ID | Title/path and locator | Revision/date | Authority scope | Status/limitations |
|---|---|---|---|---|

## 3. Vision baseline
Summarize promise, core loop/workflow, pillars, identity, protected decisions,
constraints, and non-goals. Separate confirmed and provisional entries.

## 4. Feature and requirement traceability
| Feature/requirement ID | Source | Pillar or enabling chain | Experience contribution | Fit class | Decision | Acceptance evidence | Milestone |
|---|---|---|---|---|---|---|---|

## 5. Findings
| Finding ID | Evidence/locator | Affected promise or rule | Consequence | Severity | Confidence | Smallest correction |
|---|---|---|---|---|---|---|

## 6. Ownership and handoffs
| Deliverable | Accountable role | Contributors | Public contract/handoff | Acceptance owner | Ownership evidence |
|---|---|---|---|---|---|

## 7. Shared-capability candidates
| Candidate | Identity | Reuse | Variability | Dependency | Contract | Stewardship | Classification and missing proof |
|---|---|---|---|---|---|---|---|---|
Each test uses Pass, Fail, or Unknown with source-backed reasoning.

## 8. Gate evidence
| Gate/requirement | Applicable? | Specified | Implemented | Tested | Accepted | Evidence or missing proof |
|---|---|---|---|---|---|---|---|

## 9. Drift and decision log
| Change | Previous baseline | Proposal | Category | Vision/boundary impact | Options | Decision owner/status |
|---|---|---|---|---|---|---|

## 10. Prioritized remediation
| Action ID | Priority | Finding | Correction | Accountable role | Dependencies | Acceptance condition |
|---|---|---|---|---|---|---|

## 11. Limits and unresolved decisions
State unverified assumptions, unavailable sources, unperformed tests, and any
approval or standards claim this review cannot establish. Omit irrelevant sections
with a brief reason. Never treat this report as a release authorization.
