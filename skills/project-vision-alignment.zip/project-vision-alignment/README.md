# Project Vision Alignment Skill Package

## Contents
- SKILL.md: revised skill entrypoint with valid YAML frontmatter.
- references/: supplied WWS source snapshots, original skill, and proposed rubric.
- templates/: vision contract and integrated alignment report.
- evaluation-cases.md: behavioral regression scenarios, not executed agent tests.

Keep the folder together when using the skill so its relative references resolve.
The standalone Markdown copy is convenient for review but is not the complete
resource package. This package has not been installed into any connected system.

## Changes from the original
- Starts with project identity and experience, rather than architecture alone.
- Adds eight review modes and a ten-step workflow.
- Protects approved decisions and distinguishes proposals from commitments.
- Adds pillar-to-feature-to-evidence traceability and scope decisions.
- Detects drift, tradeoffs, contradictions, and pivots.
- Retains WWS shared-capability tests and downward dependency boundaries.
- Uses the six source-backed charters rather than unsupported department assignments.
- Supports tools and non-Unreal projects without imposing game-specific requirements.
- Separates missing evidence from failure and plans from tested implementation.
- Replaces blanket prediction and ISO compliance language with applicable evidence checks.
- Adds stage-sensitive gates, exception records, templates, and regression scenarios.

## Source notes
The attached Development Core, catalog, stakeholder briefing, and original skill
are bundled without modification. The mission statement was available as parsed
attachment content but not as a separate local file; the stakeholder briefing
provides the corresponding mission and philosophy content in this package.
The catalog is a supplied snapshot, not a complete or verified current portfolio.
All new rubric and report conventions are proposals, not approved WWS policy.
