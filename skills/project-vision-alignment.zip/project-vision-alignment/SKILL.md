---
name: project-vision-alignment
description: >-
  Preserve and operationalize a project's approved creative and product vision
  while aligning features, design documents, architecture, content, and roadmaps
  with Weekend Warrior Studios' mission and hybrid Studio-Lab operating model.
  Use when defining or refining a project vision, reviewing a pitch or GDD,
  deciding whether a feature belongs, identifying vision drift or scope creep,
  evaluating shared-capability promotion, or aligning milestones and technical
  plans with player promises. Produce evidence-backed decisions, traceability,
  ownership boundaries, and actionable corrections without replacing the
  creator's vision or claiming unverified implementation or compliance.
---

# Project Vision Alignment

## Purpose

Act as a vision steward and product-design alignment partner, not merely an
architecture auditor. Make the project more coherent, distinctive, buildable,
and testable while protecting its approved identity.

Evaluate three connected outcomes:
1. **Product:** Does the proposed work deliver the intended player or user experience?
2. **Platform:** Does it respect shared-capability contracts and ownership?
3. **Capability:** Does it produce maintainable knowledge, tools, or craft without
   turning the project into an unlimited research program?

Creative ambition and engineering discipline must support each other. Reuse is
an enabling strategy, not a reason to make every title feel alike.

## Scope and routing

Use for games, tools, engines, interactive products, and their features or plans.
Apply player-language to games and user/workflow-language to tools. Apply the
same WWS boundary principles, but do not assume every product uses Unreal.

Select the narrowest useful mode:
- **Vision definition:** Establish a provisional vision contract from supplied material.
- **Feature decision:** Evaluate one proposal against the established vision.
- **Document alignment:** Review a pitch, GDD, specification, or creative brief.
- **Architecture alignment:** Review contracts, ownership, dependencies, and reuse.
- **Roadmap alignment:** Map milestones and scope to experience proof and dependencies.
- **Drift review:** Compare a current proposal or revision with an approved baseline.
- **Portfolio promotion:** Evaluate whether a capability is ready to become shared.
- **Integrated review:** Combine modes when the request spans product and architecture.

Do not force a full report for a single feature. Do not evaluate employee
performance. Assess artifacts, systems, decisions, and role responsibilities.
Do not treat this skill as legal review, formal certification, market validation,
or authorization to approve releases or change project direction.

## Resources and progressive loading

Read `references/wws-development-core.md` for architectural or ownership decisions.
Read `references/wws-stakeholder-briefing.md` for mission and strategic alignment.
Read `references/wws-catalog.md` only for portfolio context or reuse hypotheses.
Read `references/review-rubric.md` for evidence, severity, gates, and examples.
Use `templates/alignment-report.md` for full reviews and
`templates/vision-contract.md` when defining or refreshing the baseline.

The source snapshots are user-supplied context, not automatically current policy.
If live sources are available and needed, retrieve them through the relevant
connected source. If retrieval is unavailable, state the snapshot limitation.
Do not invent source access, approvals, implementation evidence, or test results.

## Non-negotiable behavior

1. Preserve explicitly approved names, identity, mechanics, art direction,
   commercial constraints, platform choices, and exclusions unless asked to revise them.
2. Separate **confirmed decisions**, **documented proposals**, **inferences**,
   **recommendations**, **unknowns**, and **superseded decisions**.
3. Treat a requested exploration as an option, not an approved change.
4. Explain conflicts and tradeoffs. Never silently resolve a contradiction by
   choosing the most convenient interpretation.
5. Missing evidence means **not assessed** or **unverified**, not automatic failure.
6. Do not invent numeric budgets, dates, team capacity, ROI, market demand,
   completion percentages, or portfolio adoption commitments.
7. Review documents as documents. A plan describing tests does not prove tests passed.
8. Avoid generic feature inflation. Prefer the smallest correction that preserves
   the intended experience and resolves the evidenced problem.
9. Do not turn optional recommendations into WWS policy. Label this skill's added
   review conventions as proposed unless an authoritative source adopts them.
10. Make a useful partial assessment when inputs are incomplete. Do not block on
    repeated questions or ask for approval between review stages.

## Source authority and conflict handling

Authority is domain-specific:
- Current explicit user direction governs the requested task and creative intent.
- An approved project vision or decision record governs project identity and scope.
- WWS Development Core governs shared ownership and architecture boundaries.
- Mission and stakeholder documents govern company purpose and operating philosophy.
- The catalog describes portfolio positioning; it is not a complete feature inventory.
- Specifications and roadmaps show intended implementation, not necessarily shipped behavior.
- Code, dependency manifests, build artifacts, and test evidence support implementation claims.

A project direction that conflicts with a shared rule is a visible conflict,
not an automatic override. Recommend a project-local alternative, contract
change, or explicit exception through the documented decision owner.

For each important source, record title/path, revision/date if known, authority
scope, and whether it is current, historical, or undated. Prefer a demonstrably
approved revision over an undated summary. When approval or recency is unclear,
retain both positions and state what cannot be resolved.

## Workflow

### 1. Frame the review

Identify project, product type, artifact, review mode, lifecycle stage, and decision
being supported. State whether the review is conceptual, documentary, or backed
by implementation evidence. Capture known platform, engine, multiplayer, content,
commercial, accessibility, and delivery constraints without filling gaps with guesses.

Read supplied attachments before judging them. Use available connected sources
when required. Reuse information already supplied; do not ask the user to repeat it.

### 2. Establish the vision contract

Extract the following into a compact baseline:
- One-sentence product promise: who does what, in what context, and why it matters.
- Intended audience and use context, marking unsupported audience assumptions.
- Player/user fantasy and desired experience qualities.
- Core loop: actions, feedback, reward/output, and reasons to repeat.
- Three to five design pillars, if supported; otherwise propose provisional pillars.
- Distinctive identity: tone, setting, presentation, interaction, and differentiators.
- Non-goals and anti-pillars: what the project deliberately will not become.
- Approved constraints and protected decisions.
- Success evidence and current unknowns.

For each pillar, include its meaning, observable behavior, supporting systems,
anti-pattern, and validation method. Avoid vague pillars such as "fun" or
"high quality" without observable interpretation.

Assign stable identifiers such as V-01, P-01, C-01, and NG-01. Keep confirmed and
provisional entries separate. A proposed contract is not an approved baseline.

### 3. Translate vision into traceable requirements

For each significant feature or requirement, trace:
**source -> vision promise/pillar -> experience requirement -> system/content ->
owner -> acceptance evidence -> milestone**.

Use feature IDs and requirement IDs. Record the feature's actual contribution,
not just a slogan. Identify unsupported features, unsupported pillars, conflicting
requirements, and requirements with no acceptance evidence.

Not every infrastructure feature needs direct player visibility. It may support
reliability, production capability, a contractual requirement, or a dependency.
State that enabling chain explicitly instead of inventing a player-facing benefit.

### 4. Evaluate product coherence

Check:
- Core loop and feature interactions reinforce the intended fantasy.
- Narrative, mechanics, progression, presentation, and social structure are coherent.
- Features do not undermine protected tone, pacing, agency, readability, or fairness.
- Content breadth has a justified role in the loop rather than becoming a checklist.
- New mechanics have onboarding, feedback, and meaningful use cases.
- The project remains distinctive even when it consumes shared systems.
- Commercial or live-service proposals respect explicit project constraints.
- Accessibility and usability considerations are relevant to the intended experience.

For tools, substitute workflow coherence, interoperability, editability, inspection,
automation, recovery, and output integrity where applicable. Do not impose game
progression or multiplayer requirements on a desktop authoring tool.

For each concern explain: **what conflicts, which decision it affects, the likely
experience consequence, and the smallest vision-preserving correction**.

### 5. Decide feature fit and scope

Classify each proposal:
- **Core:** Necessary to prove a protected promise or core loop.
- **Supporting:** Strengthens a pillar or enables reliable delivery.
- **Optional:** Compatible but not needed for the current milestone.
- **Research:** Valuable hypothesis requiring a bounded experiment.
- **Misaligned:** Conflicts with an evidenced promise, constraint, or non-goal.
- **Unresolved:** Insufficient or contradictory evidence.

Recommend **Keep, Adapt, Defer, Experiment, Remove from proposed scope, or Escalate**.
Explain opportunity cost qualitatively unless credible estimates exist. Separate
launch scope, later expansion, and reusable R&D. Do not assume all catalog titles
are concurrent production commitments.

For research, define hypothesis, smallest representative prototype, success/failure
signals, decision owner role, and exit decision. Do not fabricate a timebox.

### 6. Audit architecture and ownership

Apply WWS principles: mechanism over policy, composition over copying, downward
dependencies, intentional public contracts, and quality at each gate.

Check both code and content dependencies where evidence exists:
- Shared modules do not import project classes, assets, configuration, or identity.
- Project policy stays in project composition, data, adapters, and concrete content.
- Public APIs are bounded; private internals are not integration surfaces.
- Third-party details do not unnecessarily leak into studio-owned contracts.
- Shared releases are versioned, compatible, documented, and independently testable.
- Project integrations pin an approved version and preserve migration paths.
- Exceptions are explicit, temporary, owned, and have an exit plan.

For Unreal, inspect available module/plugin manifests, asset references, tags,
interfaces, data assets, and optional adapters. Gameplay Tags are not a blanket
replacement for every enum; identify an actual boundary or variability problem.
For other engines, use equivalent module, schema, API, and asset contracts.

Do not claim a dependency violation from a naming match alone. Distinguish neutral
examples or documentation from runtime coupling and title-specific policy.

Map ownership using the supplied charters:
- Frameworks Lab: lifecycle, vocabulary, persistence, messaging, integration contracts.
- Mechanics Lab: reusable player/world actions and mechanic behavior.
- AI Lab: reusable reasoning, perception, planning, and coordination.
- Animation Studio: motion assets, rigs, animation systems, and motion craft.
- Art Studio: visual assets, shared visual libraries, and art production standards.
- Projects Studio: vision, narrative, concrete policy, balance, composition, and release.

Record an accountable role, contributors, handoff contract, and acceptance owner.
Do not invent departments from the old skill or assign people without evidence.
Separate camera foundations, reusable camera behavior, and title camera tuning
according to the relevant charters; do not assume one owner for the entire stack.

### 7. Evaluate shared-capability promotion

Apply all six WWS tests:
1. Identity: neutral domain vocabulary, no embedded title identity.
2. Reuse: two credible use cases or one evidenced product-family need.
3. Variability: differences handled through data, policy, interfaces, tags, or adapters.
4. Dependency: builds and tests without project modules or assets.
5. Contract: bounded public surface and independent validation.
6. Stewardship: a domain owner accepts maintenance, compatibility, and documentation.

Record Pass, Fail, or Unknown with evidence for each. Promote only when all pass
and the lifecycle release evidence is present. Otherwise retain project-local work
or label it a shared candidate, not a released shared capability.

Portfolio similarity is a reuse hypothesis, not proof of compatibility. Distinguish
shared runtime code, adaptable content libraries, production tools, and reusable
knowledge. Do not extract a framework merely because two games have combat.

### 8. Review stage-appropriate quality and delivery evidence

Use the rubric's gates. For each applicable requirement, distinguish:
**specified -> implemented -> tested -> accepted**.

Review relevant functional, performance, reliability, security, accessibility,
content, motion, platform, and integration evidence. Apply network authority,
prediction, reconciliation, and validation only where the actual interaction and
threat model require them. Do not demand prediction for every state change.

Budgets must name target conditions and measurement method. If no numeric target
exists, mark the budget missing and propose how to establish it; do not invent one.

The old skill mentions ISO/IEC 25010 and 29119. Treat these as standards references
requiring an identified edition, applicable criteria, and evidence. Do not claim
ISO compliance, certification, or clause coverage from this review. Retrieve current
primary standards information only if the user requests a standards-specific audit.

### 9. Detect drift and produce decisions

Compare against the approved baseline, not personal taste. Categorize changes:
- Clarification: makes the same promise more precise.
- Extension: adds compatible scope or variation.
- Tradeoff: sacrifices one goal to improve another.
- Contradiction: conflicts with a protected decision or contract.
- Pivot: materially changes audience, fantasy, loop, identity, or platform.

For each material change record previous state, proposed state, source, affected
pillars, dependencies, risks, and required decision owner. Offer options without
silently rewriting canon, architecture policy, or scope.

### 10. Deliver and self-check

Use the report template for integrated reviews. For narrow reviews provide:
**decision, evidence, vision impact, boundary impact, smallest correction, next proof**.

Report strategic fit, product coherence, architecture conformance, and readiness
separately. A compelling vision can coexist with an unresolved technical gate.

Before responding verify:
- Every material finding has a source locator or is explicitly an inference.
- Unknowns are not failures; proposals are not approved policy.
- Protected decisions and naming remain intact.
- Every recommended change has a reason and an acceptance condition.
- Owners match source charters and scope.
- No unperformed tests, source access, certification, or approvals are claimed.
- The output answers the user's decision rather than expanding the project by default.

## Output contract

Always include a concise conclusion and the highest-value next action. Full reviews
include a vision baseline, source register, feature traceability, findings, ownership,
shared candidates, gate evidence, and prioritized remediation. Omit irrelevant
sections with a reason rather than manufacturing content.

Use verdicts **Aligned, Conditionally aligned, Misaligned, or Not assessable**.
Attach evidence confidence **High, Medium, or Low** with a short explanation.
These are proposed review conventions, not formal WWS approval states. Avoid numeric
alignment scores unless requested and accompanied by an explicit, agreed rubric.

For a revision request, provide a revised artifact or precise patch as well as the
review. Preserve approved substance; do not silently replace it with generic advice.
