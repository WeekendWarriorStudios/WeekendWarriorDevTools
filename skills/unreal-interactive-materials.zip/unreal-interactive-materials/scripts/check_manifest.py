#!/usr/bin/env python3
"""Validate a proposed, read-only JSON asset manifest. Does not access Unreal."""
import json,sys
from pathlib import Path

def validate(data):
 errors=[]
 if not isinstance(data,dict) or not isinstance(data.get('assets'),list) or not data['assets']:
  return ['manifest must contain a non-empty assets list']
 seen=set()
 for i,a in enumerate(data['assets']):
  if not isinstance(a,dict): errors.append(f'assets[{i}] must be an object');continue
  for key in ('path','type','action','purpose','dependencies'):
   if key not in a: errors.append(f'assets[{i}] missing {key}')
  p=a.get('path','')
  if not isinstance(p,str) or not p.startswith('/Game/') or '..' in p:errors.append(f'assets[{i}] invalid Unreal path')
  if p in seen:errors.append(f'assets[{i}] duplicate path {p}')
  seen.add(p)
  if a.get('action') not in ('CREATE','UPDATE'):errors.append(f'assets[{i}] invalid action')
  if not isinstance(a.get('dependencies'),list):errors.append(f'assets[{i}] dependencies must be list')
 return errors

if __name__=='__main__':
 if len(sys.argv)!=2: print('usage: check_manifest.py manifest.json');sys.exit(2)
 try: data=json.loads(Path(sys.argv[1]).read_text())
 except (OSError,ValueError) as e:print(f'ERROR: {e}');sys.exit(2)
 issues=validate(data)
 print('\n'.join('ERROR: '+x for x in issues) if issues else 'PASS: manifest structure valid (not Unreal compile validation)')
 sys.exit(bool(issues))
