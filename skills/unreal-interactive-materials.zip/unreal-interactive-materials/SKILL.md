---
name: unreal-interactive-materials
description: design and after explicit approval author physically realistic static and interactive unreal engine 5 materials and functions, landscape and voxel surfaces, water, wetness, deformation, weathering, destruction reactions, fluidninja live, niagara and chaos niagara effects using verified mcp tools. use for shader graphs, master materials, material instances, surface interactions, procedural terrain, optimization, and material package validation.
---
# Unreal Interactive Materials — production workflow

Create physically credible, reusable material systems, not merely attractive shader examples. Target UE 5.8 for ALTER EGO unless the project reports a different version. Treat all plugin API specifics as version-dependent until checked against project documentation or tools.

## Non-negotiable operating mode: Option C, approval-based
1. **READ ONLY:** Discover connected MCP capabilities, installed plugins, existing project assets, renderer/platform, and available docs. Read relevant reference chapters below.
2. **DESIGN:** Produce the complete Material Package: physical model, node-by-node graph, assets and dependencies, surface-state architecture, interaction/event contracts, performance tiers, tests, and exact proposed changes.
3. **APPROVAL GATE:** Stop before creating/modifying/saving/deleting any Unreal project asset or settings. Ask for explicit approval of the enumerated manifest. Do not interpret a request to design a material as permission to modify a project.
4. **IMPLEMENT AFTER APPROVAL:** Invoke only discovered, connected MCP operations with verified schemas. Execute in dependency order; inspect return status and compile results. Stop on unexpected conflicts. Never fabricate an asset or report success from a plan.
5. **VERIFY AND REPORT:** Provide actual asset paths, compile warnings, test evidence, skipped operations, unsupported operations and manual editor steps.

## Request classification and routing
- PBR, master material, layering, Material Function or graph → `references/01-pbr-shaders.md`, `02-graph-recipes.md`.
- Sand/grass/mud/rock/snow/soil, landscapes, voxel terrain → `03-terrain-voxel.md`, `04-material-library.md`.
- Wood/concrete/asphalt/metal/glass/paint → `04-material-library.md`.
- Footprints, tire tracks, bullet impacts, wetness, weather, damage, persistence → `05-state-and-interactions.md`, `06-niagara-chaos.md`.
- Rivers/lakes/puddles, water surface, splashes, FluidNinja → `07-water-fluidninja.md`.
- MCP asset creation, material graph automation, approval → `08-mcp-authoring.md`.
- Profiling, scalability, multiplayer → `09-optimization.md`.
- Quality acceptance, reproducible examples → `10-validation.md`, `11-worked-examples.md`.
- Structured outputs and manifests → `12-templates.md`.

## Deep implementation manuals (read for relevant tasks)
- Detailed Landscape graph construction and paint layers: `references/13-landscape-build-manual.md`.
- Water/liquid shader construction and **FluidNinja Live-2 output RT, density and velocity binding**: `references/14-fluid-materials-build-manual.md`.
- Sand, mud, snow, grass, concrete, wood, asphalt, metal, glass graph recipes: `references/15-surface-specific-graph-recipes.md`.
- Official documentation index and verification grades: `references/16-source-index.md`.

## Design procedure
1. Determine target (static mesh, skeletal mesh, Landscape, Voxel, Water), material family, visual reference, real-world scale, texture availability, renderer, target hardware, camera distance, multiplayer requirements, and whether interactions are cosmetic or gameplay-critical. State reasonable assumptions if unspecified.
2. Specify substrate composition and physical response: dielectric/metal, microfacet roughness, anisotropy, porous absorption, wetness, coating, weathering, damage, displacement and any separate collision or geometry requirements.
3. Plan function composition and parameter schema before graph construction. Identify texture source, color space, normal convention, packing, UV scale, blend behavior, material domain/blend mode/shading model and platform restrictions.
4. Build a typed graph recipe: named nodes, inputs, output pins, expressions, connection order, exposed parameters, parameter ranges, debug switches, and a simple fallback. No vague 'add detail' instructions.
5. Design runtime interaction routing: event source → surface classification → authoritative state if needed → local state writer → material sampling → Niagara/Chaos/FluidNinja visual response → decay/persistence. Distinguish shader illusion, particle VFX, actual geometry deformation and gameplay physics.
6. Provide near/mid/far quality tiers, costs and profiling plan; avoid unlimited render-target updates, global scene capture, excessive shader permutations or unbounded particle spawns.
7. Produce approval-ready asset manifest with create/update action, exact intended path, dependencies, changes, tests and rollback. Stop before mutation.

## Required deliverable structure
Use `references/12-templates.md`. Every material package must include: assumptions, physically grounded surface behavior, texture/mesh requirements, graph recipe, functions and parameter table, runtime state/event flow, VFX bindings, scalability, asset manifest, test matrix, unresolved plugin API questions and explicit approval checkpoint. After approval append an execution report.

## Correctness boundaries
- Never invent MCP method names, plugin Blueprint nodes, Niagara data interfaces, or Voxel/FluidNinja APIs. Mark 'verify in installed version' and give a tool-independent implementation plan when uncertain.
- Chaos Niagara consumes Chaos physics events for VFX; it is not the fracture solver. Niagara/FluidNinja visuals do not automatically modify collision, terrain or network-authoritative state.
- Material Parameter Collections are for global parameters; per-object Dynamic Material Instances and spatial masks have different scope. A shader cannot persist footprints without a state writer/store.
- Unreal Landscape and Voxel surface/layer systems require distinct binding adapters. Water shading, water gameplay volumes, and fluid VFX are distinct systems.
- No arbitrary numerical performance guarantees; measure on target hardware. Explicitly label illustrative defaults as starting points, not measured physical constants.
- Use project-provided Voxel.md, Water.md, FluidNinjaLive*.md, Niagara.md, NiagaraToolsets.md, ModelContextProtocol.md and StudioMCPTools.md when available; references here are design guidance, not substitutes for those plugin API documents.
