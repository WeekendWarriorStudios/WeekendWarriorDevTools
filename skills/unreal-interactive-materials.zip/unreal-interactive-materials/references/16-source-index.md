# Source index and evidence policy

## Authoritative engine documentation to consult
- Landscape materials: https://dev.epicgames.com/documentation/en-us/unreal-engine/landscape-materials-in-unreal-engine
- Landscape painting: https://dev.epicgames.com/documentation/en-us/unreal-engine/landscape-paint-mode-in-unreal-engine
- Material Functions: https://dev.epicgames.com/documentation/en-us/unreal-engine/material-functions-in-unreal-engine
- UE Water system: https://dev.epicgames.com/documentation/en-us/unreal-engine/water-system-in-unreal-engine
- Fluid render target tutorial (UE4.27, conceptual only): https://dev.epicgames.com/documentation/en-us/unreal-engine/creating-a-fluid-surface-with-blueprints-and-render-targets?application_version=4.27

## FluidNinja Live-2 canonical references
- Manual: https://majorsmash.github.io/fnl-docs-v2/manual/ninjalive2-manual/
- External RT binding: https://majorsmash.github.io/fnl-docs-v2/set-topics/live-2-external-rendertargets/
- Parameters: https://majorsmash.github.io/fnl-docs-v2/descriptors/ninjalive2-params/
- Product scope: https://www.fab.com/listings/80fcf53e-49f7-4635-a71c-ba81280c6618?lang=en

## User-supplied documentation (not bundled)
Voxel.md; Water.md; FluidNinjaLive.md; FluidNinjaLive_1.md; FluidNinjaLive_2.md; FluidNinjaLive_3.md; Niagara.md; NiagaraToolsets.md; ModelContextProtocol.md; StudioMCPTools.md. If these are accessible, search exact plugin APIs and build a source-to-claim ledger; do not infer version or feature availability from filenames. The previous skill did not bundle these files; do not pretend otherwise.

## Evidence grading
`VERIFIED-IN-PROJECT`: queried installed version and callable API; `DOCUMENTED`: explicit vendor/Epic documentation; `DESIGN`: architectural recommendation; `UNVERIFIED`: needs editor/MCP inspection. For each plugin-specific asset step, attach source URL/document section, version and grade. External links can change; verify when actually implementing.
