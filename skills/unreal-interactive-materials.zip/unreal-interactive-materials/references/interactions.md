# Interaction architecture

## Event contract (proposed)

`SurfaceEvent { type, world_position, normal, radius_cm, strength_0_1, direction, surface_id, instigator_id, timestamp, seed }`

Examples: Footstep, TireContact, ProjectileImpact, Explosion, Splash, Rain, Heat, Freeze, Scrape, Fracture.

## Routing

1. Gameplay/physics supplies event, material/surface identity and authoritative state when required.
2. State writer updates bounded interaction masks, per-object state, voxel stamp/metadata, or other persistence mechanism.
3. Material samples state to vary albedo, roughness, normals, height/parallax or emissive response.
4. Niagara spawns local dust, splash, sparks, leaves, spray or debris based on surface and event.
5. Chaos Niagara consumes actual Chaos collision/breaking/trailing events for destruction-driven VFX where available.
6. FluidNinja Live may simulate localized smoke, flow, liquid-like visuals, wind or tracked effects if the installed version supports the chosen pathway.

## Design cautions

- GPU VFX is cosmetic by default. Do not treat particle simulation as collision authority.
- Do not drive permanent terrain changes only with a transient render target.
- Use local clipmaps/tiled render targets, bounded stamps or sparse state for large worlds; document clearing, decay and persistence.
- For gameplay-relevant footprints or tracks, server records compact stamps/events and clients reconstruct visuals; bound history and use interest management.
- Use material physical parameters and surface metadata to choose effect variants, rather than creating one monolithic Niagara system for every surface.
- Add test cases for event burst rates, overlapping stamps, cross-tile boundaries, origin rebasing, pooled emitters, and replication.
