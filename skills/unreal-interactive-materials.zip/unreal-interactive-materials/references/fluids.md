# Water, wetness and FluidNinja Live

Treat four separate responsibilities explicitly:

1. **Water geometry and shading**: Unreal Water body/mesh, waves, normals, absorption/scattering, foam, shoreline, caustics, underwater rendering.
2. **Gameplay water**: waterbody collision/query, buoyancy, swimming, depth, wetness state and replication.
3. **Secondary VFX**: Niagara ripples, splashes, foam and spray; Chaos Niagara for physics-event-driven effects.
4. **Localized visual simulation**: FluidNinja Live presets/components for smoke, wind, tracks or fluid-like effects, subject to installed preset capabilities.

For a river or lake package, specify WaterBody type, spline/bank integration, material parameters, water depth and flow signals, Niagara Water Data Interface use if available, shoreline wetness and surface transitions. For a wet mud package, specify moisture mask source, drying behavior, puddle threshold, footprints, splash effects and whether any Voxel deformation is truly required.

The user-provided docs mention WaterBody actors, WaterSpline, NiagaraDataInterfaceWater, Gerstner waves, buoyancy, baked shallow water; FluidNinja Live docs mention NinjaLiveComponent, activation/interaction volumes, water presets, track painter presets and render-target utilities. Verify actual exposed functions and asset paths before automated authoring.
