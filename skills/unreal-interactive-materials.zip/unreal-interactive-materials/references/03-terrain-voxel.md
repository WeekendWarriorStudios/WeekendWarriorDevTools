# Landscape and Voxel terrain integration

## Landscape
Define named landscape layers (e.g. Soil, Grass, Mud, Sand, Rock, Snow), target layer infos, weight/height blending, slope and altitude masks, macro tiling and near/far detail. Avoid assumptions that every LandscapeLayerBlend output carries physical material identity. For gameplay, resolve physical material or explicit surface IDs using tested traces and layer queries.

## Voxel
Separate Voxel surface type/metadata/layer assignment from Unreal Landscape paint layers. Plan Mega Material or layered surface binding according to installed Voxel version. For terrain deformation use verified voxel edit/stamp/sculpt operations, not shader-only height. Account for chunk rebuild cost, save/load persistence, server authority, network relevance and stamp limits. Design shader state masks separately from persistent voxel topology edits.

## Surface classification contract
`SurfaceID` stable identifier, substrate category, wetness capacity, traction, hardness, impact sound, particle family, deformation policy, persistence policy. SurfaceID is not automatically a PhysicalMaterial enum; implement a mapping adapter for Landscape, Voxel and mesh actors.

## LOD policy
Near: layered micro normals and localized interaction mask; mid: lower-cost macro variation and limited state detail; far: simplified blends, no per-impact state texture updates. Use measured distances from game camera and visual tests rather than universal cutoffs.

## Terrain checklist
Check seams across Landscape components or Voxel chunks, steep slopes, overhangs, holes, river banks, origin shifting, runtime painting, foliage transitions, physical surface query, persistence and multiplayer reconciliation.
