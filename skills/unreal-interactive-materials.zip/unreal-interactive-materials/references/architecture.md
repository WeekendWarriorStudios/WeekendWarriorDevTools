# Asset architecture and conventions

Use these as project conventions, not claims that assets already exist.

- `M_` master material, `MI_` instance, `MF_` reusable function, `MPC_` material parameter collection, `PM_` physical material, `RT_` render target, `NS_` Niagara system, `NE_` emitter, `BP_` Blueprint, `DA_` data asset.
- Proposed path: `/Game/Materials/<Family>/` with `Functions`, `Instances`, `Textures`, `Interactions`, `FX`, `Data`.
- Core functions: `MF_SurfaceUV`, `MF_MacroVariation`, `MF_MicroNormal`, `MF_HeightBlend`, `MF_WetnessResponse`, `MF_DirtAccumulation`, `MF_DamageMask`, `MF_InteractionSample`, `MF_DistanceQuality`.
- Separate reusable surface response from surface-specific textures and from event generation.
- Typical PBR channels: base color, normal, roughness, metallic, ambient occlusion, optional height, opacity/transmission, emissive; never apply metallic values to ordinary mud, wood or concrete.
- Preserve texture color space: base color sRGB; normals, roughness, metallic, masks and height linear. Specify packing conventions, normal orientation and physical texture scale.
- Provide scalar/vector/texture parameters with type, unit, default, safe range, and owner (instance/MPC/dynamic instance).
- Use Material Parameter Collections for sparse global values, dynamic material instances for per-object changes, and localized textures/state for spatial footprints or damage. Avoid per-object dynamic instances for every world instance unless required.
- Plan static base shader plus optional interaction layers and quality switches. Verify Nanite/displacement support against actual engine settings.

## Review manifest template

For every asset record: path, type, create/update, dependencies, graph summary, writer/source, expected performance impact, verification method. Require explicit user approval of this manifest before authoring.
