# Graph construction recipes

## Naming and typed function contract
Functions return `MaterialAttributes` when practical, or explicitly typed float/float2/float3/mask. Use `MF_` prefix, `M_` masters, `MI_` instances, `MPC_` collections, `RT_` render targets, `PM_` physical materials. Parameters: `P_` scalar, `C_` color, `T_` texture, `S_` static switch. Include default, unit, range, editor group and owner.

## MF_ScaledUV
Inputs: `UV:float2`, `WorldScaleCm:float`, `TextureTileCm:float`, `RotationRadians:float` (optional). Outputs `UVOut:float2`. For mesh UVs multiply UV by an artist-specified tiling scale; for world-projection use world XY/XZ/YZ and blend by surface normal, mapping world centimeters to tile centimeters. Guard divide by zero, rotation seam and precision. Never claim UV channel 0 corresponds to meters without mesh convention.

## MF_MacroVariation
Inputs `WorldPos:float3`, `MacroTexture:texture`, `MacroTileCm:float`, `Strength:float`; output `Tint:float3` and `Mask:float`. Sample low-frequency macro texture, center variation around 1, clamp result, multiply base color. Blend out with distance if needed. Do not introduce lighting-shaped dark patches.

## MF_WetnessResponse
Inputs `DryBaseColor:float3`, `DryRoughness:float`, `DryNormal:float3`, `Wetness:float`, `CavityMask:float`, `Porosity:float`, `PuddleMask:float`; outputs `WetBaseColor`, `WetRoughness`, `WetNormal`, `WaterCoverage`. Compute absorbed moisture = saturate(Wetness * Porosity * cavity-weight), darken diffuse within tuned bounds, lower roughness in film-covered areas, soften micro normals. Use water coverage as distinct layer; avoid forcing all wet pixels to mirror finish. Provide debug outputs for each mask.

## MF_HeightBlend
Inputs `AAttributes`, `BAttributes`, `BlendWeight`, `HeightA`, `HeightB`, `Contrast`. Compute a normalized, smooth transition from weighted relative heights; clamp and avoid zero denominators. Blend material attributes with appropriate normal blending. Verify compatible shading models and shader cost. For Landscape layer blend, respect actual layer blend configuration.

## MF_InteractionSample
Inputs `WorldPos`, `InteractionOrigin`, `WorldToUV`, `StateTexture`, `Bounds`; outputs `Compression`, `Moisture`, `Damage`, `Deposit`. Sample within bounded tile; return zero outside; define channel contract. Add explicit debug visualization material to display channels. State textures require an external writer.

## Master graph build order
1. Create parameter groups and texture objects/samples.
2. Establish UVs and scale; sample albedo/normal/ORM/height.
3. Build dry substrate Material Attributes.
4. Add macro/micro detail and geometric masks.
5. Apply wear/accumulation and moisture layers.
6. Read spatial interaction channels (if enabled) and apply response.
7. Set final material attributes and validate each isolated feature.
8. Create instances and test default/fallback permutations.

## Diagnostic switches
Provide debug display for layer weights, UV grid, wetness, roughness, normal, height, interaction channels and surface ID. Avoid shipping costly debug branches; use editor-only debug materials where possible.
