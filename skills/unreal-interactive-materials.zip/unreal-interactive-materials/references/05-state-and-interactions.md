# Surface state, events, and persistence

## Proposed data contract (project-specific, not an Unreal API)
`SurfaceEvent { EventID, Type, WorldPositionCm, WorldNormal, RadiusCm, Intensity01, Direction, SurfaceID, InstigatorID, Timestamp, Seed }`
`SurfaceState { Wetness01, Compression01, Damage01, Dirt01, Heat01, AgeSeconds }`.
State is not automatically replicated or persisted. Define owners, update rates and storage.

## Three implementation tiers
A. **Object-level:** scalar parameters via MID/custom primitive data where supported; ideal for uniformly wet/dirty objects. No spatial footprints.
B. **Spatial visual:** local RT, sparse stamp atlas or other bounded GPU/CPU mask; support footprints, tire marks, scorch, puddles. Define world-to-UV transform, tile lifecycle, border blending, update scheduling, decay, save policy and precision.
C. **Persistent topology:** Voxel edits, mesh swaps, decals with collision-independent appearance or runtime mesh changes. Use only when actual shape/collision/persistence is required; measure cost and networking.

## Event pipeline
1. Detect event on appropriate authoritative source: movement contact, projectile trace, rigid-body collision, weather volume, damage event.
2. Resolve surface ID, physical material and material state; apply gameplay effects separately from VFX.
3. Filter by intensity and cooldown; coalesce repeated contacts, deduplicate EventID, limit area and rate.
4. Write state to the correct owner. For local RT, transform world hit to tile UV, blend brush footprint, clamp channels, mark dirty tile.
5. Broadcast compact cosmetic event to relevant clients; Niagara spawns selected effect, FluidNinja if suitable, sound/decal optional.
6. Material reads state on subsequent frames; evolve drying, healing, erosion or persistence at bounded cadence.

## Channel packing example
R=wetness, G=compression, B=damage, A=deposits. This is an illustrative convention, not required by Unreal. Document precision, overlap rules, erase policy and whether stamps accumulate or take max.

## Multiplayer
Server authority for movement friction, deformable collision and durable world changes. Replicate sparse events or compact tile changes to interested clients, not full high-frequency simulation textures. Seed cosmetic FX deterministically where helpful, handle late join via snapshot plus subsequent events. Avoid unbounded history.

## Failure cases
Repeated contacts flooding RT, texture boundary seams, footprints on moving meshes, origin rebasing, high-speed vehicles, overlapping players, streaming unload/reload, pooled actors retaining state, weather globally touching every tile, late join divergence, GPU readback stalls. Add explicit tests for each relevant case.
