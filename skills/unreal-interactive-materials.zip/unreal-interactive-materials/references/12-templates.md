# Mandatory Material Package templates

## Design brief
`Name | Target UE/plugin versions | Material family | Geometry target | Environment | Scale | Reference assets | Interaction types | Persistence | Multiplayer | Hardware | Assumptions`.

## Asset manifest
For each item:
- `Asset path / asset type / CREATE or UPDATE / existing? / dependencies / purpose / graph or setup summary / automation availability VERIFIED|UNKNOWN|MANUAL / test / rollback`.

## Function specification
For each Material Function:
- `Name, responsibility, inputs (type/unit/default/range), outputs (type), ordered nodes/connections, dependencies, edge cases, debug mode, shader cost risk`.

## Parameter sheet
`Name | type | default | safe range | unit | owner (MI/MID/MPC/state) | runtime writer | visual effect`.

## Interaction contract
`Source event | surface resolution | state mutation | authority | storage | persistence | shader response | Niagara | Chaos | FluidNinja | network transport | rate limit`.

## Approval checkpoint
Explicitly state: "No Unreal project assets have been changed. Approve the following manifest to authorize MCP writes: ...". If MCP not connected, state authoring is not available and give manual implementation instructions. Approval applies only to listed mutations.

## Execution report
`Approved scope | MCP tools used | asset path | created/updated/skipped/failed | compile result | validation evidence | deviations | manual work | rollback instructions`.
