# Landscape material construction — detailed reference

## Objective and asset set
Build `M_Landscape_Master`, `MI_Landscape_<Biome>`, `MF_LandscapeLayer`, `MF_SlopeMask`, `MF_HeightTransition`, `MF_DistanceTiling`, `MF_WeatherState`, `MF_InteractionAtlasSample`, layer textures, and Layer Info assets. Target UE 5.8; check current Landscape material documentation and material graph APIs before execution.

## Step-by-step graph
1. Set material domain Surface, shading model Default Lit (unless project renderer requires another), Use Material Attributes true. Decide whether Nanite Landscape, RVT, displacement or virtual textures are actually supported in target project.
2. Create TextureObjectParameters per layer: albedo, normal, packed ORM, optional height. Create ScalarParameters for `TileSizeCm`, `MicroDetailStrength`, `MacroScaleCm`, `NormalIntensity`, `RoughnessBias`, `HeightContrast`, `WetnessCapacity`.
3. UV strategy: for world projection, divide AbsoluteWorldPosition XY by tile size in centimeters; for LandscapeCoords, document MappingScale relative to actual landscape dimensions. Add camera-relative precision strategy if large worlds. Derive separate macro UVs and detail UVs. Avoid using identical tiling for every scale.
4. Layer function: sample albedo sRGB, normals as tangent normals, masks as linear; split packed channels by declared convention; use `MakeMaterialAttributes` with base color, metallic 0 for soil/grass/sand, roughness, normal, AO. Return attributes and height mask separately.
5. Define `LandscapeLayerBlend` layer names exactly matching painting layers. Choose Weight Blend for broad substrate coverage, Height Blend where height-driven mixing is intended; avoid all-height-blend black patches by keeping a weight-blended base or appropriate fallback. Check node behavior in installed version.
6. Blend material attributes with compatible functions and layer weights. Normalize masks, check material attribute pins and normal blend correctness. Create debug material that renders each weight/height mask independently.
7. Slope: `dot(PixelNormalWS or geometry normal, WorldUp)` gives slope-related factor; use geometry normal for stable biome placement when detailed normals should not change classification. Remap with SmoothStep-like threshold. Use altitude and erosion masks from world generation as additional independent controls.
8. Add distance tiling: near detail normal/roughness fades with camera distance; mid macro color persists; far simplified sampling avoids noisy aliasing. Never use abrupt hard cuts.
9. Weather: use global rain/snow temperature only as inputs. Local wetness requires per-tile mask or explicit state writer. Compute damp darkening and roughness changes; puddle mask from cavity/flatness and saturation. Keep physical collision separate.
10. Foliage: Landscape Grass Output or PCG/PCGEx placement reads appropriate layer masks; grass meshes need their own wind/flattening materials. Do not equate ground shader grass tint with physical blades.
11. Bind Physical Material or Surface ID via a tested Landscape-specific resolver; layer blends may complicate per-hit material determination. Validate trace results on transition zones.
12. Test with 1 m reference grid, daylight, grazing light, overcast and rain; inspect layer seams, black pixels, normal flips, repeated textures, sampler count and shader complexity.

## Parameter examples (starting values, not measured)
- TileSizeCm: 100–400 cm depending on source texture physical coverage.
- MacroScaleCm: 1500–8000 cm for broad color breakup.
- Wetness01: 0–1; DryingSeconds: 60–1800 depending on simulation intent.
- Near detail fade: camera-tuned; do not hardcode globally.

## Failure modes
Layer naming mismatch, height blend zero weights, normal-map green channel inversion, incorrect packed channels, landscape component seams, triplanar overdraw, costly layer count, runtime material recompilation, stale RVT, wetness masks misaligned after origin shifting.

## Authoritative reading
Epic Landscape Materials: https://dev.epicgames.com/documentation/en-us/unreal-engine/landscape-materials-in-unreal-engine
Epic Landscape Paint Mode: https://dev.epicgames.com/documentation/en-us/unreal-engine/landscape-paint-mode-in-unreal-engine
Epic Material Functions: https://dev.epicgames.com/documentation/en-us/unreal-engine/material-functions-in-unreal-engine
