# Worked design examples (not prebuilt Unreal assets)

## Example A: interactive wet mud on Voxel terrain
**Goal:** dry-to-saturated mud with foot/tire impressions and splashes.
**Assets:** `MF_MudSubstrate`, `MF_WetnessResponse`, `MF_InteractionSample`, `M_TerrainMud`, `MI_TerrainMud_Wet`, `RT_MudState_Tile` (runtime pool), `NS_MudContact`, `PM_Mud`, surface routing component and optional Voxel stamp writer.
**Inputs:** albedo, normal, roughness, height, cavity, macro noise; `Wetness01`, `Compression01`, `Puddle01`, `WorldToTileUV`.
**Graph:** world/terrain UV → dry albedo/ORM/normal → cavity mask → wetness function → state texture sample → compression changes normal/roughness and local puddle fill → Material Attributes. Debug each mask independently.
**Event:** contact trace/physics event → Voxel surface ID mapping → event strength/radius → server-owned traction state (if required) → local visual RT stamp → Niagara mud droplets; optional FluidNinja visual track simulation only if verified. For true ruts use approved Voxel edit API with cost and persistence limits.
**Test:** dry/wet/saturated, overlap, repeated contacts, tile seams, late join, stream reload, camera distance, peak vehicles.
**Approval:** list all create/update assets and exact runtime writers; no writes before consent.

## Example B: concrete wall fracture
**Assets:** `M_Concrete_Master`, `MI_Concrete_Poured`, `MF_ConcreteWeathering`, `NS_ConcreteFracture`, Chaos Geometry Collection asset, physical surface mapping.
**Graph:** macro cast variation + aggregate detail + cavity roughness + streak masks + wet response + optional damage state. Fracture mesh geometry is separate from shader cracks.
**Event:** Chaos fracture/collision event → Chaos Niagara compatible interface → magnitude-filtered dust/chips. Distinguish simulated Chaos chunks from cosmetic Niagara fragments; add audio and gameplay damage separately.
**Test:** small impact vs major break, event storms, debris duplication, high-speed camera, multiplayer visibility, peak solver cost.

## Example C: interactive riverbank
**Assets:** WaterBody setup, water material instance, shore wetness function, shoreline state source, `NS_ShoreSplash`, optional FluidNinja localized effect.
**Graph:** water depth/flow/wave shading separate from terrain dampness; wetness band on adjacent sand/rock based on shore distance and contact state.
**Event:** actor crosses water surface → gameplay wetness state + Niagara splash/ripples → shore material state. No assumption that Niagara controls buoyancy.
**Test:** changing waterline, river bend, sloped shore, swimming transition, reflection, distant LOD, network spectators.
