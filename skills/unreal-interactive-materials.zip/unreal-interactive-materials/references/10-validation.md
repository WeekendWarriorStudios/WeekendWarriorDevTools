# Quality gates and test plan

## Gate 1: specification
All assets named and dependency-ordered; typed graph outputs, textures/color space, units/defaults, surface state ownership, plugin capability ledger, performance fallback and approval manifest included.

## Gate 2: shader correctness
Compile with zero blocking errors; verify UV scale with measured reference, correct tangent normals, no black/NaN pixels, no UV seam artifacts, plausible roughness/metalness, dry/wet transitions and lighting stability. Verify Material Instance overrides and layer masks.

## Gate 3: interaction correctness
Test single footstep, overlapping footsteps, tire tracks, high-speed impacts, bullet hits, repeated collision events, decay, terrain boundaries, moving mesh, streaming unload/reload and optional save/load. Confirm visual mask and gameplay state are intentionally separated.

## Gate 4: plugin integration
For Niagara: emitter binds actual surface event attributes. For Chaos Niagara: breaking/collision/trailing event source verified. For FluidNinja: source/volume/preset activation and output target verified. For Water: body queries, shoreline and splash effects tested. For Voxel: layer mapping and edit persistence tested. Mark any unverified subsystem pending.

## Gate 5: performance and network
Benchmark near/mid/far in stress scene; record GPU/CPU and memory, particle peak, RT tiles, voxel rebuild times. Test authoritative state on server, client reconstruction, late join, relevancy and cleanup. No claim of optimization without measurements.

## Release report format
`PASS / FAIL / NOT TESTED` for every applicable gate; include asset paths, build/engine version, tested hardware, screenshots/log excerpts if tools supply them, known limitations, rollback plan and outstanding manual steps.
