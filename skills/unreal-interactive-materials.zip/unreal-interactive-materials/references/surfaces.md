# Surface family recipes

## Terrain and landscape

- Sand: grain-scale normal, wind ripples, dune macro variation, compactness, dry/wet darkening, footprint masks, blown dust.
- Grass: soil/grass layering, density and seasonal color, foliage mesh integration, flattening/bending response, dampness and footstep events; do not simulate blades via expensive per-pixel effects alone.
- Mud: clay/silt composition, puddle fill, specular/roughness transition, footprint and tire-track depth mask, displaced rim appearance, splash particles; geometry deformation is separate from shader normals.
- Snow: powder/packed/ice blend, compression, sparkle restraint, footprints and melt/wet state.
- Rock/gravel: geological layering, aggregate size, weathering, edge damage, dust and loose particle reactions.

## Built materials

- Wood: grain direction, end grain, pores, varnish, scratches, soaking, charring, splinters on break.
- Concrete: aggregate, pores, formwork seams, cracks, exposed reinforcement only when geometry supports it, wetness, dust and fracture VFX.
- Asphalt: aggregate, tar roughness, road wear, rubber marks, wet road reflections and impact dust.
- Metal: correct metalness, anisotropy only when supported, oxidation, coatings, scratches, heat discoloration and sparks.
- Glass: thickness and transmission considerations, grime, cracks, fracture mesh and shards; select shading model per project renderer.

## Landscape/Voxel integration

Unreal Landscape layer weights and Voxel surface types/metadata are different data sources. Provide a separate binding plan for each. For Voxel, consider Surface Types, layered/mega materials, metadata, sculpt/stamp operations, and runtime cost. Never assert direct interchangeability with Landscape layers. Use physical-material/surface classification for impact routing; confirm how blended layers select physical properties in the target renderer.
