# Performance, scalability and multiplayer

## Cost model
Track shader instructions, texture samples, virtual texture bandwidth, shader permutations, translucent overdraw, RT memory and update bandwidth, Niagara particle and collision cost, Chaos solver load, voxel edit/chunk rebuild cost and CPU-to-GPU synchronization. Measure on target hardware.

## Quality tiers
High: full near-field layered detail and localized interactions, bounded high-resolution state, high-quality particles. Medium: reduced micro normal layers and interaction update frequency, fewer particle emitters. Low: simplified material instance, decals/normal illusion, low-frequency state updates or no persistent cosmetic masks. Distances and resolution must be configurable, not hardcoded universal values.

## Render-target sizing
Memory estimate = width * height * bytes per pixel * buffers * active tiles; include mipmaps and temporary buffers separately. Example: one 1024x1024 RGBA8 target is 4 MiB before mips; two ping-pong buffers are 8 MiB. Track number of resident tiles and write rate. Consider quantization and channel precision.

## Material complexity
Limit texture layers per pixel; use material instance parameters for tuning, static switches only for major compile-time branches. Use mip-aware microdetail, roughness filtering and macro color to avoid aliasing. Validate triplanar cost, world-position precision and runtime virtual texture compatibility.

## Runtime event budgets
Throttle per actor, per surface tile and per frame. Merge co-located events, cull offscreen cosmetic effects, pool Niagara components, decay state in batches, avoid full-world render-target updates and per-frame CPU readbacks. Replicate authoritative sparse state; clients render cosmetic effects.

## Profiling checklist
Record GPU material pass, translucency, Niagara, water, RT updates, CPU physics and voxel rebuild separately. Test worst-case crowd/vehicle/weather/destruction overlap, not only an isolated material sphere. Note settings, resolution, hardware and measurement date.
