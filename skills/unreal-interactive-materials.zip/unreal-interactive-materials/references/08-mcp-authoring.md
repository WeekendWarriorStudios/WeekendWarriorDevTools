# MCP-assisted Unreal asset authoring

## Discovery (read-only)
Discover actual connected MCP tools and their schemas; verify project root, engine version, plugin enablement, target renderer, existing asset paths, MaterialGraph and MaterialFunction capabilities, Niagara creation/edit capability, asset compilation and asset query methods. User-provided StudioMCPTools and ModelContextProtocol docs are evidence of possible integration, not a live connection. Never invent `create_material` or any other method.

## Planning and approval
Produce manifest with path, type, action, dependency, exact change summary, expected compile risk, rollback strategy. Identify which changes can be automated with verified tools and which are manual. Require explicit user approval before any writes, including saves, project config changes, graph edits, asset creation and deletion.

## Execution after approval
1. Recheck conflicts and relevant tool availability.
2. Create shared Material Functions and parameter contracts first.
3. Create masters and connect graphs in topological dependency order.
4. Create material instances and bind texture parameters.
5. Create interaction data assets/RTs/Blueprint or C++ bridge only when supported and approved.
6. Create/configure Niagara and FluidNinja integrations only when supported; otherwise output manual steps.
7. Compile/save, inspect errors and run validation with tools that actually exist.
8. Report asset paths and statuses. Never treat a successful tool request as proof of shader compile success.

## Failure handling
Stop on unexpected existing asset, missing dependency, unsupported node, invalid pin, compile error or write permission failure. Do not delete/recreate assets to 'fix' without separate approval. Preserve original assets and provide reversible changes where possible. If partial execution occurs, report exact completed assets and remaining steps.

## Capability ledger
For each requested operation: `Operation | MCP tool actually discovered | supported parameters | result | fallback`. Use `unknown` until verified, not optimistic assumptions.
