# Material family recipes and interaction requirements

For each family supply base substrate, texture set, masks, moisture response, physical gameplay attributes, VFX reaction, persistent-state policy and quality fallback. These are starting designs; inspect reference imagery and asset scale.

## Sand
Grain micro normal, wind-ripple medium normal, dune-scale macro color, compactness, moisture darkening, granular slope and footprints. Impacts emit sand puffs; wind emits drifting grains. Footprint depression is shader illusion unless Voxel/geometry edits are authorized.

## Soil and mud
Soil: clods, humus, pebbles, pore/cavity mask and dampness. Mud: clay/silt, variable viscosity appearance, saturated sheen, shallow puddles, tire ruts and shoe prints. Distinguish compression mask from actual volume displacement; add splash and sticky residue VFX; drying may crack the appearance over time.

## Grass and foliage ground
Layer soil and grass litter in ground shader, spawn grass meshes separately; flatten/bend foliage via supported interactive foliage mechanism, not only ground normals. Include trampled grass state, dew, seasonal dryness, wind and footstep sounds. Avoid expensive per-blade material logic at distance.

## Rock, gravel, snow and ice
Rock: stratification, mineral inclusions, cracks, wetness; fracture dust. Gravel: aggregate variation, loose particles and displaced stones. Snow: powder versus compacted crust, compression, dirt deposition and melting; snowprints need spatial state. Ice: smooth roughness variations, trapped bubbles, frost and fracture visuals; collision friction belongs to gameplay physics.

## Wood
Longitudinal grain, end grain, knots, pore variation, rough-cut versus varnished finish, paint/varnish layer, wet absorption, abrasion, charring. Bullet/impact response: decals or local damage state, splinters and dust; structural fracture is a separate Chaos Geometry Collection or authored breakage asset.

## Concrete, brick, plaster and asphalt
Concrete: cement paste, exposed aggregate, pores, casting seams, efflorescence, staining, rebar exposure where geometry permits. Brick: mortar separate material response, chipped edges and wet porous darkening. Plaster: layered paint, peeling, cracks and dust. Asphalt: aggregate, tar, tire marks, rain sheen, puddles and impact debris. Destruction events can drive Chaos Niagara particles but do not create new fracture geometry themselves.

## Metal, paint, rubber and glass
Metal: substrate metalness, brushed anisotropy when supported, oxide/corrosion, coatings, scratches and impact sparks. Painted metal: dielectric paint on metal with exposed metal scratches; don't make paint metallic. Rubber: matte porous microstructure, scuffs, wet traction separate from visual shader. Glass: transmission/thickness/refraction decisions by renderer, smudges, condensation, cracks and distinct shard/structural behavior.

## Water, oil, blood and chemicals
Treat as separate liquid visual and gameplay families with correct optical, viscosity-appearance, absorption and interaction rules. Use Water plugin for suitable bodies, localized Niagara/FluidNinja visuals for effects, and gameplay volumes for collision/buoyancy. Never infer real fluid dynamics from a translucent shader alone.

## Coverage matrix requirement
For every requested material, document: dry, damp, saturated, deposited dirt, abrasion, thermal damage, collision impact, foot/vehicle contact, particle effect, persistent state, and fallback. Mark inapplicable interactions explicitly.
