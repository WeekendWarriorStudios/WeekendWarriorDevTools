# Unreal Water and FluidNinja Live

## Water body material
Define water type (river, lake, ocean, pool, puddle), depth, flow direction, wind, wave spectrum, surface normals, foam, shoreline attenuation, underwater absorption/scattering, caustics and reflections. Choose supported shading model and rendering path from project version; translucent water may differ from opaque surfaces in depth and sorting.

## Water gameplay
WaterBody collision/query, buoyancy, swim state, submerged depth and water surface height belong to gameplay/Water integration, not the surface shader. Confirm actual Water plugin data interface and WaterBody actor APIs before MCP authoring. Keep visual wave displacement consistent enough with gameplay query to avoid visible contact errors.

## Shallow-water interaction
Map character/vehicle/physics contact to splash event and ripple source. For persistent ripple fields, choose bounded simulation texture or documented water simulation. Shoreline wetness should affect adjacent sand/mud/rock via a separate state/mask path. Avoid assuming Niagara particles alter water collision.

## FluidNinja Live integration
Consult installed docs for NinjaLiveComponent, presets, interaction volumes, track painter, RT writing and supported simulation types. Treat FluidNinja as a localized visual solver for smoke, wind, fluid-like flow, reactive trails or material masks only where verified. Document activation lifecycle, bounds, resolution, world alignment, source injection, material sampling, Niagara interoperability and cleanup. Do not claim FluidNinja replaces WaterBody, Chaos rigid physics or authoritative hydrodynamics.

## Example wet shoreline
Water surface/depth query → shore distance/moisture mask → wet sand/rock material layer; movement event → gameplay wetness + splash Niagara → optional FluidNinja local flow/spray → drying decay; actual shoreline erosion or voxel deformation requires separate terrain edit.

## Acceptance
Inspect shore seams, waterline at different camera angles, depth-dependent opacity, moving waves, reflected highlights, high-speed contact, overlapping ripples, wetness fade, scalability, replication and origin shifting.
