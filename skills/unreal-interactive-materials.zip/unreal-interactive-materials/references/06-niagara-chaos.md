# Niagara and Chaos Niagara integration

## Responsibility map
Niagara: visual particles and GPU/CPU simulation. Chaos physics: rigid-body simulation, collisions and Geometry Collection fracture. Chaos Niagara: exposes compatible Chaos event data to Niagara; verify installed data interfaces and emitters. Physics Fields: influence supported Chaos simulations; field-driven gameplay requires explicit logic and tests.

## Effect routing
Use surface-event type, substrate ID, contact velocity/intensity, angle and moisture to select effect family and parameterize particle count, size, color, lifetime, drag and emission direction. Avoid an unbounded one-system-per-material explosion; prefer shared effect families with data-driven parameter sets.

## Contact effects
- Sand/soil: dust puffs, grains and trailing debris, suppressed when saturated.
- Mud/water: splashes, droplets, mist, rings, mud flecks, volume scaled by event.
- Wood: chips, sawdust, fibers; fractured geometry is separate.
- Concrete/brick: fine dust, chips, impact sparks only when material/impact warrants.
- Metal: sparks and occasional flakes, material/impact dependent.
- Grass: leaf fragments and pollen only when appropriate.

## Chaos-driven destruction
1. Ensure geometry collection/fracture and Chaos event generation actually configured.
2. Verify Chaos Niagara destruction/collision/breaking/trailing event interface in installed version.
3. Bind event position, normal, velocity, surface/material classification and size when exposed.
4. Map event magnitude to dust and debris effect with rate limits and visual-only GPU particles.
5. Distinguish Chaos rigid fragments from Niagara decorative particles. Avoid double-counting physical debris.

## Optimization
Prefer pooled Niagara systems, scalability/culling, fixed maximum spawn counts, distance-aware effect tiers, LOD emitters and local simulation bounds. Profile overdraw and GPU cost, not just particle counts. Limit persistent ribbons/trails and expensive collision modules.

## Verification
Check single impacts, repeated rapid impacts, overlapping fractures, moving platforms, submerged hits, network spectators, distant events and CPU/GPU Niagara variants. Mark plugin nodes and event attribute names as version-specific until inspected.
