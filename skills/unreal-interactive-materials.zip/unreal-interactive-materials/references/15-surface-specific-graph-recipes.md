# Practical per-material shader graphs

## Shared template
`UV / WorldPosition → texture samples → macro/micro normals → dry MaterialAttributes → cavity and height masks → environmental layers → interaction state → output attributes`. Every branch must have a documented mask, coordinate space, parameter type, and test view. The graph is conceptual until converted to verified Unreal nodes.

## Sand
Inputs: albedo, grain normal, ripple height/normal, packed ORM, wind macro noise, compression RT. Graph: two spatial scales of normals → RNM/angle-correct blend → macro color variation → cavity roughness → wetness response → compression changes ripples and darkens compacted grains. Niagara event: contact dust scales with dryness and speed. If Voxel supports terrain edit, optional rut stamp; otherwise normal-only illusion.

## Grass and soil
Ground substrate is soil, litter, moss, short vegetation coverage. Height-blend soil and green ground layer, keep grass foliage mesh separate. Wind from global MPC or FluidNinja velocity feeds foliage WPO where supported. Contact writer stores trample mask, foliage bends via verified actor/foliage interaction. Ground roughness darkens with dew and rain; Niagara leaf/dirt bursts are optional.

## Mud
Dry soil attributes → pore/cavity mask → saturated albedo/roughness transition → standing-water coverage → local compression RT. Tire contact stamps elongated brush along path; footprint stamps oriented sole texture. Rim bulge is normal/parallax illusion unless actual voxel edit. Niagara mud splash and droplet adhesion can use velocity and water content.

## Snow
Powder albedo and roughness, micro-crystal normal, packed-snow material and exposed soil. Compression state blends powder to compacted snow, height mask changes normal; temperature/melt converts to wet layer. Real snow depth and collision requires geometry/voxel state, not shader alone.

## Concrete
Cement base, aggregate flecks, pores, cast seams, stains, efflorescence, edge wear. Impact RT controls scorch/dust decals or damage mask; Geometry Collection break events drive Chaos Niagara dust. Do not draw fake exposed rebar where fracture geometry cannot reveal it.

## Wood
Object-aligned grain UV, separate end-grain mapping, knots, pore normal, varnish layer. Water absorption follows grain/porosity, scorch mask blackens and increases roughness, chip decals on impacts. Wood fracture geometry and collision handled outside shader.

## Asphalt
Aggregate albedo/normal, bitumen roughness, tire wear, painted road marking layer, rain wetness and puddle fill. Vehicle events stamp skid masks; Niagara dust/droplets selected by wetness.

## Painted metal
Metal substrate and dielectric paint as separate coverage masks. Exposed scratches reveal metallic substrate; rust is oxide/dielectric surface with appropriate roughness. Heat tint/scorch state and impact sparks. Avoid setting metallic=1 for paint or rust.

## Glass
Specify supported shading model, thickness, transmission, refraction and sorting. Add smudges, dust, water droplets and damage crack mask; actual breakage is mesh/Chaos, not crack texture. Test across deferred/forward renderer as configured.

## Validation for each recipe
Reference-scale checker, normal orientation, dry/wet under three lights, macro tiling, transition masks, stress event and lowest-quality fallback. If textures unavailable, create a placeholder plan rather than claiming photorealism.
