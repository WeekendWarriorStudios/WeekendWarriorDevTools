# Fluid materials: liquid shading, flow, state and effects

## Choose the correct system
- WaterBody: river/lake/ocean geometry and queries.
- Surface shader: optical properties and normals for water, oil, wet mud, slime, blood or shallow puddles.
- Niagara: droplets, spray, ripples, foam, smoke and particles.
- FluidNinja Live-2: surface-aligned visual simulation, velocity/density, painting and volumetric/surface output where documented.
- Gameplay physics: buoyancy, friction, flow forces and authoritative collision; must be separately implemented.

## Material optical recipe
1. Identify liquid and container geometry: infinite water body, shallow puddle, film on mesh, flowing rivulet, pool, volume or decal-like effect.
2. Specify material domain and blend/shading mode supported by the target renderer. For clear water, decide opacity, absorption, depth fade, Fresnel, roughness, refraction, reflection, wave normal, foam and underwater appearance. For opaque mud/blood/oil films, consider a layered surface material rather than defaulting to translucent overdraw.
3. Flow direction: build a UV velocity field (world-space direction projected onto surface), integrate time into scrolling detail maps; use two phase-shifted flow samples with blend reset to avoid visible stretching. Sample actual FluidNinja velocity RT when available, mapping simulation UV to material UV.
4. Density/wetmap: read FluidNinja density or wetmap RT and remap to opacity, base color, roughness, emissive or foam. Define expected channel semantics and thresholds explicitly; no assumptions about buffers across plugin versions.
5. Surface normals: derive low-frequency waves from simulation height if provided, plus tiled micro normal maps; normalize blend. For RT height, finite-difference neighboring texels to derive gradients, with texel size based on RT dimensions. Beware border sampling and mip behavior.
6. Shorelines: obtain water depth and bank distance from Water/landscape or explicit signed distance/height fields. Foam where waves break or intersect banks; wet nearby terrain via separate state mask.
7. Contact: foot/vehicle/projectile emits world-positioned event. Convert to local sim UV; inject density/velocity/brush via verified component interface; trigger Niagara droplets/splash and optionally material wetness. Bound event count and sim area.
8. Validation: correct orientation, motion direction, material transparency and sorting, depth fade, foam continuity, shoreline seams, normal scale, high-speed impacts and no visual 'water climbing' unless intentional.

## FluidNinja Live-2 setup — documented workflow
1. Inspect installed plugin version and example levels/presets. Live-2 differs from Live-1; do not mix component variable names without checking.
2. Choose Live Actor/Component and an appropriate preset (water, wetmap, smoke, flow, track painter) from installed examples; verify runtime compatibility.
3. Establish simulation bounds, world-to-sim mapping, surface alignment, sources and obstacle inputs (landscape elevation, mesh SDF, splines, particles, destructible chunks as supported).
4. Prefer DirectDrive for simple tagged-mesh output if suitable; for material reuse, configure LiveOutputRenderTargets with existing RT assets and connect RT texture parameters to material instances.
5. Documented Live-2 external RT example: `LiveComponent / LiveOutputRenderTargets / SimVelocityDensityAndWetmap / RT_VelocityDensity`. Confirm exact property in project. Exposing external RT replaces an internal target rather than necessarily allocating a second target; avoid shared RT collision across actors.
6. For simulation world transform/extent, check `LiveComponent / LiveOutputParams / SetInternalParamsToMaterialParamCollection` in installed version. Bind the resulting MPC fields to shader UV conversion, not arbitrary UV offsets.
7. If multiple Ninja actors share a material, allocate distinct RTs or explicitly manage a compositing atlas. On spawn, assign RTs and update material bindings before enabling simulation.
8. Add interaction injection from gameplay, surface-aligned particle or Chaos inputs where verified; never claim simulated density modifies physical water collision.
9. Profile simulation resolution, activation radius, sparse/dense mode, particle coupling, RT format, temporal persistence and multiplayer reconstruction.

## Reference examples
**Puddle:** opaque terrain wetness layer + thin standing-water shader or Water surface; rain stamps → ripple RT/Niagara; wet edge mask decays.
**Flowing mud:** substrate shader + dynamic wetness and streak flow from Ninja velocity/density; separate Voxel stamps for physical ruts.
**Waterfall:** spline/mesh flow material + Niagara spray/mist + optional FluidNinja density and velocity; gameplay water volume independently configured.
**Smoke interacting with walls:** Ninja surface/volume aligned smoke density, obstacle SDF where available, output material and separate particle sparks.

## Primary documentation
FluidNinja Live-2 Manual (updated 2026): https://majorsmash.github.io/fnl-docs-v2/manual/ninjalive2-manual/
Live-2 external render targets: https://majorsmash.github.io/fnl-docs-v2/set-topics/live-2-external-rendertargets/
Live-2 parameter descriptor: https://majorsmash.github.io/fnl-docs-v2/descriptors/ninjalive2-params/
Epic render-target fluid surface (older UE 4.27 concept reference, NOT drop-in 5.8 instructions): https://dev.epicgames.com/documentation/en-us/unreal-engine/creating-a-fluid-surface-with-blueprints-and-render-targets?application_version=4.27
