# PBR and physical reference

## Surface definition
Record scale in centimeters/meters, substance, fabrication, wear, environment, roughness range, metalness, reflectance intent, normal frequency, and how state evolves. Do not derive albedo from screenshots with baked shadows. For measured data, document lighting and capture calibration; when measurements are unavailable, mark artistic estimates.

## Texture handling
- Base color: sRGB, diffuse color without baked illumination. ORM/RMA masks, normal and height: linear/non-color. Specify packed-channel map per project; never silently swap roughness and metallic.
- Normals: specify tangent-space handedness (DirectX vs OpenGL green channel), compression, normalization and tangent basis. Use angle-corrected normal blending or a verified equivalent, not naïve RGB lerp for all cases.
- Roughness: vary with pores, polish, abrasion, wetness, deposits; avoid arbitrary extremes. Metallic is generally binary for exposed metal versus dielectric, with transitional pixels from mixtures/antialiasing rather than 'half-metal concrete'.
- Height: distinguish microparallax, tessellation/displacement, actual mesh/voxel modification. A height map alone does not change collision.
- AO: fine-scale occlusion only; do not bake large directional shadows into albedo. Validate under neutral daylight, grazing light, overcast, night, and wet conditions.

## Scale-aware texture stack
Base texel density is chosen per asset/camera. Separate macro color breakup (meters), medium detail (centimeters) and microdetail (millimeters). Blend with distance to prevent high-frequency aliasing. World-aligned projection may stretch on moving/skinned meshes and may cause swimming; use object/UV anchors as appropriate.

## Wetness model
Represent `Wetness` in [0,1] as state, not a fixed 'darken' multiplier. Wetness may lower diffuse albedo, change roughness and specular response, fill cavities first, flatten fine normals, create a thin water layer or puddles and alter particles/audio. Porous surfaces soak; nonporous surfaces bead/run off. Separate 'damp', 'saturated', 'standing water'. Consider hysteresis and drying time. For physically plausible interfaces use a verified layered shading approach when renderer supports it; otherwise label approximations.

## Layered shader decisions
Use Material Attributes or compatible Material Layers for substrate, coating, deposits and response. Separate masks for coverage, height blend, wetness, damage and interaction. Prefer shared Material Functions with typed outputs and stable signatures. Each static switch creates shader permutations: reserve for actual platform/feature families, not every artistic tweak.

## Required review
Verify shader domain, blend mode, two-sidedness, shading model, texture samplers, VT/RVT usage, Nanite compatibility, normals, shadow behavior, shader complexity, PSO permutations and material instance override behavior.
