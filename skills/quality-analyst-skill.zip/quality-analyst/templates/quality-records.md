# Quality Record Templates

## Finding
- ID/title:
- Classification: defect / design concern / preference / evidence gap / infrastructure issue
- Requirement and source:
- Environment/build/version:
- Expected behavior:
- Actual behavior:
- Evidence and claim status:
- Severity / priority / confidence:
- Frequency: failures / attempts; observation unit
- Reproduction steps or known triggering context:
- Scope and workaround:
- Hypotheses and counterevidence:
- Proposed intervention and tradeoffs:
- Acceptance criterion:
- Original and adjacent regression tests:
- Verification status and evidence:

## Test case
- ID and linked requirement/finding:
- Purpose and risk:
- Preconditions/data/seed:
- Environment and role:
- Steps:
- Expected state and observable output:
- Measurement method:
- Pass/fail criterion and approval status:
- Cleanup/recovery:
- Execution status/build/result/evidence:

## Hypothesis
- Explanation and confidence:
- Supporting evidence:
- Strongest alternative:
- Discriminating test:
- Expected observation if true:
- Observation that would weaken it:
- Cost, constraints, and next decision:

## Telemetry event
- Name/schema/build:
- Question and decision:
- Trigger and source/authority:
- Timestamp semantics:
- Correlation/session identifiers:
- Payload and units:
- Deduplication and missing-data handling:
- Privacy, access, and retention:
- Validation test:

## Metric
- Name/question:
- Numerator/denominator/unit:
- Population/cohort/build:
- Observation window:
- Exclusions and missing-data treatment:
- Aggregation and uncertainty method:
- Proposed decision threshold and approval status:
- Guardrails and confounders:

## Release gate
- Gate/requirement:
- Approved criterion or proposed target:
- Required evidence:
- Tested build and scope:
- Result: pass / fail / untested / inconclusive
- Residual risk:
- Waiver authority if documented:
- Recommendation, not release authorization:
