# Quality Analysis Report

## Summary and decision
Subject, requested decision, primary mode, provisional conclusion, and verification status.

## Scope and intent
Project/build, versions, platforms, lifecycle, requirements, constraints, exclusions, and explicitly inferred intent.

## Evidence ledger
| ID | Source/revision | Direct observation | Limitation |
|---|---|---|---|
| E-001 | Unknown | Not yet established | Evidence required |

## Prioritized findings
For each: finding ID, category, severity, priority, confidence, requirement, expected/actual behavior, evidence IDs, affected scope, workaround, and uncertainty.

## Interaction timeline and failure layers
Map the relevant sequence and first observed divergence. Distinguish local/server/observer or document/viewport/disk states.

## Competing hypotheses
For each: explanation, supporting/counterevidence, discriminating test, predicted result, and disconfirming result.

## Recommendations
Specific intervention, expected effect, tradeoffs, dependencies, proposed acceptance criterion, verification method, and rollback/recovery.

## Verification matrix
| Test ID | Requirement/finding | Scenario/environment | Expected result | Executed? | Evidence/result |
|---|---|---|---|---|---|
| T-001 | Pending | To define | To define | No | Not verified |

## Release or decision recommendation
Use only if requested. State agreed/proposed gates, evidence, failed gates, accepted risks if supplied, and authorization boundary.

## Residual risks and next evidence
Unknowns, untested combinations, limitations, and smallest next discriminating check.
