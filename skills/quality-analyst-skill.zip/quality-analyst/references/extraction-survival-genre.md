# Extraction and Survival Quality

This is an optional genre module. Do not assume extraction mechanics, a named nemesis, factions, cards, or safehouses exist in the user's project.

## Stay-versus-extract decision
Map current carried value, future opportunity, perceived threat, extraction availability, objective completion, and session constraints. Early extraction can be rational and intended. A high early-extraction percentage alone does not prove broken pacing.

Compare carried-in and carried-out value, progression stage, mission type, party composition, available objectives, and reason for leaving. Test competing explanations: sufficient goal completion, weak later rewards, excessive loss risk, session time constraints, or misleading instrumentation.

## Loss and persistence
Verify death, disconnect, process termination, reconnect, insurance/recovery if present, and extraction transactions. Define exactly when rewards become persistent. Check duplicate grants and lost rewards around interrupted transitions.

## Nemesis or escalation systems
Inspect identity persistence, readable adaptation, counterplay, escalation ceilings, and payoff. Avoidance can reflect intentional strategy, poor rewards, numerical pressure, or unclear counterplay. Verify the intended response before changing difficulty.

## Factions and reputation
Test consequences, recoverability, reward access, UI clarity, persistence, and interactions. Do not assume factions must be zero-sum; independent reputation may be intentional.

## Safehouse and squad systems
Inspect resource conversion, upgrade choices, companion assignment if present, shared/private state, extraction agreement, rescue, reward attribution, and disconnect recovery. Test asymmetric squad states and late joining.

## Verification
Use session cohorts and explicit decision observations. Avoid optimizing toward maximum session length; the target is meaningful agency and the intended experience. Keep project-specific systems in project context rather than this shared reference.
