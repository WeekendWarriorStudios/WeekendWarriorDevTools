# Engine, Plugin, Renderer, Networking, and Pipeline Quality

## Version discipline
Capture engine version/commit, plugin version/commit, build configuration, platform, and relevant project configuration. Consult actual source and primary documentation for API names and settings. If unavailable, provide conceptual checks and mark implementation details unresolved.

Do not carry historical engine labels, feature availability, console variables, or plugin claims into a current diagnosis without verification.

## Ability and movement integration
Inspect input acceptance, eligibility, cost/cooldown, tags, movement mode, animation, collision, cancellation, and cleanup. Trace event ordering rather than assuming a race. Test interruption, rejection, repeated activation, and teardown.

## Network authority and prediction
Identify who owns each state and validates each action. Separate predicted presentation, predicted local simulation, server-authoritative outcomes, and remote replication. For an apparently delayed dodge, trace activation, immunity state, hit evaluation, and reconciliation separately.

Do not assert that every delay equals a full round trip. Define whether injected latency is one-way or round-trip, and account for tick, buffering, and processing. Packet loss does not automatically mean a reliable message disappears permanently; inspect transport, retries, timeout, and application lifecycle.

Do not assume generic lag compensation exists or is enabled. Inspect the actual hit-validation/rewind implementation. Client-predicted immunity is not sufficient proof that server damage evaluation is correct.

## Network matrix
Test client/server/observer views, dedicated/listen topology if supported, join-in-progress, disconnect/reconnect, process termination, relevancy changes, dormancy, delay, jitter, loss, and reordering where tools support it. Choose exploratory profiles from project needs, not purported population averages.

Compare shared authoritative state where it should agree. Do not require private inventory or deliberately asymmetric reputation to be identical across players.

## Plugin lifecycle and messaging
Inspect dependency declarations, initialization, activation, deactivation, reload, component injection, listener lifetime, and shutdown. Verify message schema, tag matching semantics, delivery context, idempotency, and ordering guarantees from implementation. Do not rely on incidental listener registration order as a stable contract.

Direct references can be valid with explicit ownership/lifetime guarantees. Identify unsafe references, not every reference. Test optional dependencies absent and shared plugins without project content.

## AI and state machines
Define expected states, transitions, priority, interrupt conditions, perception inputs, and persistence. Compare logs with the expected sequence. Do not invent debug flags. Inspect utility decisions and state transitions separately before attributing delay to evaluation timing.

## Performance and rendering
Separate CPU, GPU, simulation, render, streaming, shader compilation, and network costs. Record hardware, resolution, quality settings, workload, build, and capture method. Compare against approved budgets and report distributions when available, not only averages.

Distinguish generated display frames from simulation throughput and input responsiveness. Inspect temporal artifacts during fast movement and UI changes. Do not assume a vendor feature or renderer capability is available on every target.

## Asset and authoring pipelines
Check units, scale, axes, skeleton compatibility, root motion, tangent space, color space, texture channels, compression, metadata, and import/export settings. Compare source asset, interchange file, engine interpretation, and runtime output.

For material/texture tools, test layer operations, masks, blending, undo/redo, project save/load, viewport consistency, export channel mapping, and renderer interchange. Treat a replacement renderer as an adapter-contract change, not just a visual swap.

For terrain, test coordinate transforms, collision/visual agreement, LOD boundaries, navigation, procedural placement, and regeneration. For animation, test actual gameplay speeds and transitions, not only authoring previews.

## Recovery
Verify resource cleanup, corrupted inputs, partial imports, failed exports, device loss where applicable, missing assets, save migration, and repeated retries. Preserve original user data and do not run destructive cleanup without authorization.
