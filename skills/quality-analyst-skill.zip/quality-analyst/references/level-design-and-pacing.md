# Levels, Pacing, and Procedural Worlds

## Spatial audit
Compare intended routes with observed routes. Inspect landmarks, contrast, lighting, navigation, sightlines, traversal affordances, objective placement, and recovery spaces. A bright object is not necessarily the intended destination; verify the actual design contract.

## Pacing
Map demand, novelty, decision density, and recovery across encounters, missions, and sessions. Distinguish planned pacing from observed behavior. Do not fabricate an intensity graph when no observations exist; provide a collection template instead.

## Encounters
Inspect teaching, threat telegraphs, counterplay, resource pressure, escape options, repetition, and combinations of known mechanics. Evaluate whether additional content is necessary or existing content is deployed poorly.

## Procedural generation
Record seed, graph/configuration revision, input data, generation region, and runtime/editor context. Test invariants: reachable objectives, valid spawn placement, clearance, navigable routes, collision consistency, and regeneration cleanup.

For roads and bridges, verify endpoint connectivity, grade and clearance constraints, water crossing detection, bank alignment, collision, navigation, and deterministic reproduction where promised. Distinguish visual continuity from actual traversability.

Test seed diversity and adversarial inputs. A few successful seeds do not establish universal correctness. Include empty inputs, dense obstacles, steep terrain, narrow crossings, streaming boundaries, and interrupted generation.

## Streaming and world boundaries
Inspect collision/nav readiness before access, persistent state across unload/reload, duplicated actors, stale references, and traversal during streaming. Record player speed and load conditions when reproducing boundary failures.

## Verification
Use explicit route completion, collision checks, objective reachability, seed reproduction, and measured performance against approved budgets. Keep aesthetic preference separate from functional failures.
