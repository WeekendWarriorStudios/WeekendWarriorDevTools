# Quality Systems, Telemetry, and Release Gates

## Question-first process
For each quality activity define the decision, question, evidence, collection method, decision rule, responsible function, review cadence, and escalation path. Ownership refers to a function or system responsibility, not employee evaluation.

## Test layers
Use unit/contract tests for isolated rules; integration tests for boundaries; scenario tests for player/operator flows; smoke tests for critical viability; regression tests for preserved behavior; exploratory sessions for unexpected interactions. Label planned tests separately from executed tests.

## Playtest methods
Discoverability tests observe unaided use. Balance tests control relevant scenario variables. Experience tests preserve natural play. Iterative usability testing can change builds between participants, but those sessions must retain build labels and must not be pooled as an unchanged controlled experiment.

## Telemetry schema
An event record should define event name, schema version, build ID, source/authority, timestamp semantics, pseudonymous session/player IDs where necessary, correlation ID, trigger, payload, deduplication, and retention. Minimize collection and protect access.

A metric record needs question, numerator, denominator, unit, population, time window, exclusions, missing-data policy, aggregation, and decision rule. Verify event integrity before diagnosing player behavior.

## Statistical safeguards
Report failures/attempts rather than a percentage without context. Distinguish player, session, match, and action units. Account for selection effects, repeated observations, build mixing, and incomplete sessions. Use justified uncertainty methods where data permits. Do not turn a heatmap concentration into proof of unfair geometry without exposure and context.

## Defect lifecycle
New -> triaged -> investigating -> fix proposed -> implemented -> verification -> closed/reopened. Permit duplicate, deferred, accepted-risk, and cannot-reproduce outcomes with rationale. "Cannot reproduce" is not proof of absence.

Separate impact, scheduling priority, frequency, and confidence. Preserve evidence for rare severe failures. Link each verified fix to original reproduction and adjacent regression coverage.

## Automation integrity
Track flaky tests, nondeterminism, fixture drift, missing dependencies, and false positives. Quarantine with documented coverage loss, not silent deletion. Test infrastructure failures are findings of their own.

## Release gates
Use project-approved gates. Suggested categories are launch/session viability, critical functional flows, data integrity, supported configurations, performance budgets, multiplayer recovery, accessibility commitments, and rollback readiness. Proposed gates require approval and do not establish platform certification.

## Incidents
Capture impact scope, timeline, triggering change, containment, evidence, systemic contributing factors, recovery validation, and prevention tests. Keep analysis blameless and artifact-focused. Do not deploy or change live configuration without authorization.
