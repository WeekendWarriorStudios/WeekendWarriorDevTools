# Progression, Economy, Balance, and Social Systems

## Progression
Compare early and late play in terms of options, execution, knowledge, narrative access, and numerical capability. Larger numbers alone are not automatically a defect; compare them with intended progression. Identify whether new options alter decisions or merely add menu overhead.

## Economy
Map resource sources, sinks, storage limits, trade, loss, duplication boundaries, and persistent transactions. Inspect new-player and established-player trajectories. Check reconnects, repeated requests, interrupted writes, and migration for duplicate rewards or lost resources.

Respect the user's monetization constraints. Do not introduce premium currency or paid progression into an earned-only economy unless requested.

## Balance
Evaluate viability, counterplay, role identity, map context, skill band, team composition, selection frequency, and matchup sample sizes. Aggregate win rate is not a sufficient diagnosis. Avoid declaring an option overpowered from one statistic.

For snowballing, trace how early advantage changes resources, map control, respawn access, objectives, and later opportunities. Compare reward tuning, objective structure, and counterplay interventions. Explain what each would preserve or weaken.

## Matchmaking and co-op
Inspect latency, queue time, party composition, rating uncertainty, role constraints, and population. Do not assume a rating algorithm or backend. For co-op, inspect shared objectives, extraction/mission agreement, reward attribution, griefing recovery, disconnect handling, and unequal progression.

## Experiment design
Define the balance question, cohort, unit of analysis, build, confounders, outcome metrics, and guardrails before comparing variants. Repeated matches by the same players require attention to dependence. A/B assignment does not by itself guarantee valid causal inference.

## Returning-player experience
Inspect re-entry clarity, missed-content recovery, save compatibility, progression catch-up, and whether returning players retain meaningful agency. Do not optimize retention through coercive or misleading mechanics.
