# Analysis Frameworks

Use frameworks to sharpen a specific question, not to replace evidence.

## Intent, behavior, outcome
Record the intended experience, observable interaction, and outcome separately. A complaint is evidence of a reported experience, not a complete causal explanation. Compare documented requirements with implementation, and player reports with observed behavior.

## Mechanics, dynamics, experience
Separate rules and verbs from patterns produced during play and from reported experience. Trace a complaint through candidate play patterns to the rules or presentation that could produce it. Do not infer feelings from images. Use direct participant statements when discussing subjective experience.

## Nested loops
Map immediate action, encounter/session goals, and persistent progression. Identify how success in one loop contributes to the next. Inspect novelty, meaningful decisions, recovery, and reward relevance. Do not diagnose the failing loop solely from the hour at which someone quits.

## Decision audit
For a meaningful choice, examine available alternatives, consequences, information, opportunity cost, and relevance to the goal. An option selected often may be accessible or popular rather than dominant. Check alternatives in their intended contexts.

## Challenge decomposition
Separate execution precision, strategic planning, system knowledge, information clarity, and cost of failure. A difficulty complaint can concern any combination. Evaluate preparation and feedback before assuming numerical tuning is the cause.

## Feedback-loop mapping
Draw state -> advantage -> reward -> next state. Identify reinforcement, stabilizers, caps, and player-controlled interruption points. A comeback intervention should preserve the value of good play while creating actionable counterplay.

## Hypothesis discipline
For each explanation, state what would be observed if it were true, what would contradict it, and what test distinguishes it from an alternative. Prefer interventions that reveal information as well as potentially improve the experience.

## Constraints
Evaluate lifecycle stage, supported platforms, multiplayer topology, content budget, dependencies, compatibility, and scope. Keep proposed changes proportionate to the actual decision.
