# Onboarding, Usability, and Accessibility

## First-use analysis
Map launch -> settings -> first input -> first meaningful action -> first goal -> first success/failure -> next objective. Inspect delays, unclear goals, unskippable material, interface overload, and unmet expectations. Early exits can also reflect crashes, performance, matchmaking, or event errors.

## Learning
Check whether each new action is introduced, practiced, reinforced, and applied in context. Prefer testing the actual flow over assuming tutorial text fixes comprehension. Preserve optional replay and reference information for returning users.

## UI and tools
Inspect discoverability, feedback, undo/redo, destructive-action recovery, validation, keyboard/controller navigation, focus, error messages, document persistence, and export clarity. A tool that renders correctly but silently loses edits has a critical quality failure.

## Accessibility feature review
Evaluate scalable text, contrast, non-color cues, remapping, toggle/hold options, captions/subtitles, adjustable timing, reduced motion, and assistive-device interaction where supported. Analyze features and barriers, not individuals' protected characteristics.

Do not claim compliance with an accessibility standard from a checklist. If a standard is requested, obtain its applicable version and criteria and distinguish advisory design targets from formal conformance requirements.

## Observation protocol
Use neutral prompts such as "What are you trying to do next?" Record observable actions and direct statements. Do not infer emotions or identity from appearance. Avoid coaching during discoverability tests; document any intervention.

## Verification
Test representative display distances, UI scales, input methods, language lengths, and supported settings. Verify that accessibility settings persist and do not break gameplay state, navigation, or critical feedback.
