# Game Feel, Traversal, Animation, and Camera

## Interaction timeline
Trace physical input, engine sampling, input acceptance, state eligibility, simulation commitment, animation, audio, camera response, and authoritative confirmation. Measure available segments separately. Do not substitute frame rate for end-to-end input latency.

## Combat impact
Inspect contact timing, hit validation, animation reaction, audio transient and mix, particles, camera response, haptics, and readability. Missing hitstop is one hypothesis, not a universal diagnosis. Proposed hitstop must account for multiplayer simulation and must not accidentally pause authoritative world state.

Compare lightweight presentation experiments against mechanic changes. State the expected effect and possible costs: obscured threats, disrupted rhythm, discomfort, misleading hit confirmation, or reduced control.

## Input contracts
Document buffer lifetime, priority, cancellation, held-input behavior, repeated presses, cooldown rejection, and feedback on invalid actions. Test at state boundaries and across simulation/render rates. Distinguish accepted input from an action that can legally commit.

## Traversal chains
For each transition capture eligibility query, target geometry, movement mode, ability state, animation state, root motion, and collision result. A stale-state race is a candidate only until a trace establishes ordering. Test clean and boundary angles, moving surfaces, interruptions, and rapid chained inputs.

Verify capsule/mesh alignment, target stability, root-motion ownership, momentum preservation, and recovery after failed commitment. Test each link and the full chain.

## Camera
Inspect intent selection, arbitration, blending, collision, occlusion, look-ahead, vertical motion, target framing, and restoration after interruptions. Test fast transitions and cramped spaces, not only average movement. Separate project camera policy from reusable camera mechanisms.

Do not assume a custom camera plugin is an engine class with a similar name. Confirm actual ownership and interfaces.

## Presentation and accessibility
Provide redundant critical cues. Inspect reduced shake/motion settings, effect intensity, captioning, haptic toggles, and readability under simultaneous events. Do not use a cosmetic cue as proof of damage, immunity, inventory mutation, or server success.

## Verification
Specify a repeatable action sequence, environment, measured timestamps where available, observable acceptance criterion, and regression scenarios. Label all tuning values as proposed unless approved requirements supply them.
