# Quality Analyst Skill Package

Version: 1.0.0
Authored: 2026-10-12
Scope: game-development quality, reusable plugins, engines, tools, and content pipelines.

## Contents
- `SKILL.md`: trigger metadata and operating instructions.
- `references/`: eight selectively loaded domain modules.
- `templates/`: analysis report and reusable quality records.
- `evals/evals.json`: 24 behavioral evaluation scenarios with explicit assertions.

## Use
Place the `quality-analyst` directory in the skill location supported by your target assistant. Keep `SKILL.md` at the directory root and preserve relative paths. Registration and evaluation commands depend on the host; this package does not assume a specific installer or runtime.

Start with a quality question and available evidence. The skill routes to the applicable reference and produces a diagnosis, audit, test plan, verification report, or release-risk recommendation.

## Changes from the supplied example
- Retains intent-first diagnosis, competing hypotheses, tradeoffs, and verification.
- Removes hardcoded historical project systems and assumed plugin stacks.
- Replaces universal timing/network thresholds with approved criteria or explicitly proposed experiments.
- Adds evidence provenance, confidence, traceability, architecture contracts, pipeline/tool quality, release gates, and privacy safeguards.
- Separates planned tests from executed tests and recommendations from release authorization.
- Rewrites evaluations to reward uncertainty handling rather than predetermined technical conclusions.

## Validation status
Package paths, frontmatter, JSON syntax, unique evaluation IDs, and archive integrity are structurally checked during creation. No game build, engine API, runtime behavior, assistant installation, or behavioral evaluation has been executed or certified.

## Maintenance
Keep shared methodology separate from project context. Record version/build evidence in each analysis. Review engine-specific guidance when dependencies change. Add an evaluation when a real failure reveals a missing analytical safeguard.
